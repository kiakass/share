# Product Requirements Document (PRD)

## 1. Product Name
**U+ Enterprise Sales Assistance** (LGU+ B2B 서비스 제안서 생성기)

## 2. Project Overview
LGU+ 영업 담당자가 고객사 환경(업종, 기업 규모)에 최적화된 맞춤형 솔루션 제안 페이지를 신속하게 생성하고 공유할 수 있도록 지원하는 Sales Enablement 도구입니다.

## 3. Core Objectives
- **Personalization**: 고객사의 업종과 규모에 맞는 시장 분석 및 제안 배경을 AI 기반으로 제공.
- **Efficiency**: 복잡한 LGU+의 B2B 상품군 중 필요한 항목만 골라 즉시 제안서 링크 생성.
- **Professionalism**: 세련되고 신뢰감 있는 디자인 언어를 통해 고객에게 긍정적인 브랜드 이미지 전달.

## 4. User Roles
- **Sales Manager (Creator)**: 상품 라이브러리에서 상품을 선택하고 제안서를 구성.
- **Client (Viewer)**: 공유받은 링크를 통해 최적화된 제안 내용을 확인.

## 5. Functional Requirements

### 5.1 Creator Workflow (CreatorPage)
- **Step 1: Client Profile**: 고객사명, 업종(Manufacturing, Retail, Finance 등), 기업 규모(Large, Medium, Small) 입력.
- **Step 2: Product Library**: 
    - 카테고리별(네트워크, 보안, 스마트팩토리, DX솔루션 등) 상품 목록 제공.
    - **Category Selection**: 카테고리별 전체 선택/해제 기능 (체크박스).
    - **AI Insight**: 선택한 업종/규모에 최적화된 상품을 AI가 추천하는 컨텍스트 제공.
- **Step 3: Build & Share**: 
    - 제안서 URL 생성.
    - 이메일 클라이언트 연동(mailto)을 통한 즉시 공유.

### 5.2 Viewer Interface (ViewerPage)
- **Hero Section**: 고객 환영 메시지 및 제안 요약.
- **Industry Insight**: AI가 생성한 업종별 시장 트렌드 및 제안 배경 설명.
- **Product Highlights**:
    - 선택된 상품 중 핵심 상품을 강조하여 상세 설명(이름, 간단 설명, 상세 내용).
    - 관련 홍보 영상(YouTube) 및 브로슈어 연결.
- **Expected Effects**: 제안 솔루션 도입 시 기대되는 효과 나열.
- **Inquiry**: 상담 신청 및 견적 문의 버튼.

## 6. UI/UX Design Specifications

### 6.1 Design Language
- **Brand Identity**: LGU+의 대표 컬러인 Pink(#ff2e98)를 포인트 컬러로 사용.
- **Aesthetic Tone**: 'Professional & Sophisticated'. 배경에 화려한 이미지나 그라데이션 대신 정제된 라인과 간결한 레이아웃을 선호.
- **Geometric Style**: 지나치게 둥근 모서리 보다는 적당한 수준의 라운딩(16px~24px)을 적용하여 신뢰감 부여.

### 6.2 Key Design Elements (Newly Updated)
- **Separators**: 섹션 구분 시 단순 여백 대신 포인트 점이 포함된 가늘고 세련된 라인을 사용하여 시각적 리듬감 부여.
- **Balanced Spacing**: 섹션 간 여백을 정교하게 조정하여 정보의 밀집도와 가독성을 최적화.
- **Visual Polish**: 불필요한 배경 장식(Blobs)을 제거하고 여백과 라인을 강조하는 미니멀리즘 구현.

## 7. Major Update History (Recent)

| 구분 | 주요 변경 사항 | 상세 내용 |
| :--- | :--- | :--- |
| **UI/UX** | **라인 구분자 도입** | 섹션 사이의 배경 이미지를 제거하고 세련된 라인과 도트 포인트로 구분. |
| **UI/UX** | **라운딩 최적화** | 박스 모서리 라운딩(`rounded-[3rem]` 등)을 전체적으로 줄여 세련된 느낌 강조. |
| **UI/UX** | **간격 조정** | 박스와 라인 사이의 불필요한 공간을 줄여 레이아웃 밀도를 높임. |
| **기능** | **카테고리 전체 선택** | 생성 페이지에서 카테고리별로 상품을 한 번에 선택/해제할 수 있는 체크박스 추가. |
| **기능** | **텍스트 최적화** | 제안 서비스가 5개 이상일 경우 '...' 말줄임표를 적용하여 가독성 유지. |
| **기능** | **조건부 문구 처리** | 특정 조건(Manufacturing, Large)일 경우 불필요한 중복 메시지 제거. |
| **기능** | **정보 표시 강화** | 뷰어 페이지 하이라이트 영역에 '서비스명'과 '서비스 설명'을 병기하여 정보 전달력 강화. |

## 8. Technical Stack
- **Framework**: React 18+ (with Vite)
- **Styling**: Tailwind CSS
- **Animation**: motion/react (Framer Motion)
- **Icons**: lucide-react
- **Optimization**: ResizeObserver를 활용한 반응형 레이아웃 대응.
