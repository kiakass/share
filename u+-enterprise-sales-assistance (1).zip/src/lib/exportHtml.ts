import { PRODUCTS } from '../constants';
import { Industry, CompanySize, Product } from '../types';

/**
 * Downloads the PRD as a standalone HTML file.
 */
export async function downloadPrdHtml() {
  try {
    const res = await fetch('/PRD.html');
    if (res.ok) {
      const htmlText = await res.text();
      triggerDownload(htmlText, 'U_Plus_Enterprise_Sales_Assistance_PRD.html');
      return;
    }
  } catch (err) {
    console.warn('Direct fetch failed, falling back to static PRD generator', err);
  }

  // Fallback: window navigation
  window.open('/PRD.html', '_blank');
}

/**
 * Helper to trigger browser download for any string as HTML file
 */
export function triggerDownload(content: string, filename: string) {
  const blob = new Blob([content], { type: 'text/html;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

interface ProposalExportData {
  clientName: string;
  industry: Industry;
  size: CompanySize;
  prodIds: string[];
  dynamicContent?: {
    trend: string;
    background: string;
    products?: string[];
  } | null;
}

/**
 * Generates and downloads a self-contained offline HTML file for the Proposal.
 */
export function downloadProposalHtml(data: ProposalExportData) {
  const { clientName, industry, size, prodIds, dynamicContent } = data;
  const proposedProducts = PRODUCTS.filter(p => prodIds.includes(p.id));
  const clientTitle = clientName ? `${clientName} 고객님을 위한` : '고객님을 위한';
  const fileName = clientName 
    ? `${clientName}_LGUplus_맞춤서비스제안서.html` 
    : 'LGUplus_Enterprise_맞춤서비스제안서.html';

  // Group products by category
  const grouped: Record<string, Product[]> = {};
  proposedProducts.forEach(p => {
    if (!grouped[p.category]) grouped[p.category] = [];
    grouped[p.category].push(p);
  });

  // Services ellipsis logic (5 or more services)
  const isOverFive = proposedProducts.length >= 5;
  const servicesSummaryText = isOverFive
    ? proposedProducts.slice(0, 5).map(p => p.name).join(', ') + ',...,'
    : proposedProducts.map(p => p.name).join(', ');

  const html = `<!DOCTYPE html>
<html lang="ko">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>${clientName ? `[LGU+] ${clientName} 맞춤 서비스 소개서` : 'LGU+ Enterprise 맞춤 서비스 소개서'}</title>
  <style>
    :root {
      --primary: #ff2e98;
      --primary-hover: #e0177f;
      --primary-light: #fff0f7;
      --dark: #221714;
      --card-dark: #2d2a28;
      --gray-bg: #f8f8f6;
      --text-muted: #82817e;
      --border: rgba(0, 0, 0, 0.08);
      --radius: 16px;
    }
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body {
      font-family: -apple-system, BlinkMacSystemFont, "Pretendard", "Apple SD Gothic Neo", "Segoe UI", Roboto, sans-serif;
      background-color: var(--gray-bg);
      color: var(--dark);
      line-height: 1.6;
      -webkit-font-smoothing: antialiased;
    }
    .header {
      background: white;
      border-bottom: 1px solid var(--border);
      padding: 16px 24px;
      position: sticky;
      top: 0;
      z-index: 50;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }
    .logo {
      display: flex;
      align-items: center;
      gap: 12px;
    }
    .logo-badge {
      background: var(--primary);
      color: white;
      font-weight: 900;
      font-style: italic;
      width: 32px;
      height: 32px;
      border-radius: 8px;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 14px;
    }
    .brand-title {
      font-weight: 900;
      font-size: 18px;
      letter-spacing: -0.5px;
    }
    .client-tag {
      font-size: 13px;
      color: var(--text-muted);
      border-left: 1px solid var(--border);
      padding-left: 12px;
      margin-left: 12px;
      font-weight: 700;
    }
    .btn {
      padding: 8px 16px;
      border-radius: 8px;
      font-size: 13px;
      font-weight: 700;
      cursor: pointer;
      border: none;
      transition: all 0.2s ease;
      text-decoration: none;
    }
    .btn-primary {
      background: var(--primary);
      color: white;
    }
    .btn-outline {
      background: white;
      border: 1px solid var(--border);
      color: var(--dark);
    }
    .container {
      max-width: 1040px;
      margin: 0 auto;
      padding: 40px 24px 80px 24px;
    }
    .hero {
      text-align: center;
      padding: 40px 0 24px 0;
    }
    .pill {
      display: inline-flex;
      align-items: center;
      gap: 6px;
      padding: 4px 14px;
      background: white;
      border: 1px solid rgba(255, 46, 152, 0.2);
      border-radius: 20px;
      font-size: 11px;
      font-weight: 800;
      color: var(--primary);
      text-transform: uppercase;
      margin-bottom: 16px;
    }
    .hero-title {
      font-size: 38px;
      font-weight: 900;
      letter-spacing: -1px;
      line-height: 1.25;
      margin-bottom: 16px;
    }
    .hero-meta {
      font-size: 14px;
      color: var(--text-muted);
      font-weight: 600;
    }
    .separator {
      margin: 32px auto;
      position: relative;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    .separator-line {
      width: 100%;
      height: 1px;
      background: rgba(0, 0, 0, 0.08);
    }
    .separator-dot {
      position: absolute;
      width: 6px;
      height: 6px;
      background: var(--primary);
      border-radius: 50%;
    }
    .card {
      background: white;
      border: 1px solid var(--border);
      border-radius: var(--radius);
      padding: 32px;
      margin-bottom: 24px;
      box-shadow: 0 4px 20px rgba(0, 0, 0, 0.02);
    }
    .card-title {
      font-size: 20px;
      font-weight: 800;
      margin-bottom: 16px;
      display: flex;
      align-items: center;
      gap: 8px;
      letter-spacing: -0.5px;
    }
    .card-title span {
      color: var(--primary);
    }
    .product-grid {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(290px, 1fr));
      gap: 16px;
      margin-top: 16px;
    }
    .product-card {
      background: #fafaf8;
      border: 1px solid var(--border);
      border-radius: 12px;
      padding: 20px;
      display: flex;
      flex-direction: column;
      justify-content: space-between;
    }
    .prod-cat {
      font-size: 11px;
      font-weight: 800;
      color: var(--primary);
      text-transform: uppercase;
      letter-spacing: 0.5px;
      margin-bottom: 4px;
    }
    .prod-name {
      font-size: 17px;
      font-weight: 800;
      color: var(--dark);
      margin-bottom: 6px;
    }
    .prod-desc {
      font-size: 13px;
      color: var(--text-muted);
      margin-bottom: 14px;
      line-height: 1.5;
    }
    .prod-specs {
      background: white;
      padding: 10px 12px;
      border-radius: 8px;
      border: 1px solid var(--border);
      font-size: 12px;
      color: #4b4845;
    }
    .footer-cta {
      background: var(--card-dark);
      color: white;
      border-radius: var(--radius);
      padding: 40px;
      text-align: center;
      margin-top: 40px;
    }
    .footer-cta h3 {
      font-size: 24px;
      font-weight: 900;
      margin-bottom: 10px;
    }
    .footer-cta p {
      color: rgba(255, 255, 255, 0.7);
      font-size: 14px;
      margin-bottom: 24px;
    }
    @media print {
      .header, .btn-print-hide { display: none !important; }
      body { background: white !important; }
      .container { max-width: 100% !important; padding: 0 !important; }
      .card { box-shadow: none !important; border: 1px solid #ccc !important; break-inside: avoid; }
    }
  </style>
</head>
<body>
  <header class="header">
    <div class="logo">
      <div class="logo-badge">U+</div>
      <div class="brand-title">Enterprise</div>
      <span class="client-tag">${clientName ? `${clientName} 전용 맞춤 제안` : '맞춤 제안'}</span>
    </div>
    <div style="display: flex; gap: 8px;">
      <button class="btn btn-outline btn-print-hide" onclick="window.print()">🖨️ 인쇄 / PDF 저장</button>
      <button class="btn btn-primary btn-print-hide" onclick="window.scrollTo({ top: document.body.scrollHeight, behavior: 'smooth' })">담당자 문의</button>
    </div>
  </header>

  <div class="container">
    <div class="hero">
      <div class="pill">Personalized Offer</div>
      <h1 class="hero-title">
        <span>${clientTitle}</span><br />
        <span style="color: var(--primary);">맞춤 서비스 소개</span>
      </h1>
      <div class="hero-meta">
        <span>업종: ${industry}</span> &nbsp;•&nbsp; <span>규모: ${size}</span>
      </div>
    </div>

    <div class="separator">
      <div class="separator-line"></div>
      <div class="separator-dot"></div>
    </div>

    ${dynamicContent?.trend || dynamicContent?.background ? `
    <div class="card">
      <h2 class="card-title"><span>01</span> 시장 분석 및 제안 배경</h2>
      ${dynamicContent?.trend ? `<p style="margin-bottom: 12px; font-weight: 500;"><strong>산업 트렌드:</strong> ${dynamicContent.trend}</p>` : ''}
      ${dynamicContent?.background ? `<p style="color: #4b4845;"><strong>도입 배경:</strong> ${dynamicContent.background}</p>` : ''}
    </div>
    ` : ''}

    <div class="card">
      <h2 class="card-title"><span>02</span> 추천 맞춤 서비스 (${proposedProducts.length}개 상품)</h2>
      <div class="product-grid">
        ${proposedProducts.map(p => `
          <div class="product-card">
            <div>
              <div class="prod-cat">${p.category}</div>
              <div class="prod-name">${p.name}</div>
              <div class="prod-desc">${p.description}</div>
            </div>
            <div class="prod-specs">
              <strong>서비스 요약:</strong> ${p.longDescription ? p.longDescription.slice(0, 100) + '...' : p.description}
            </div>
          </div>
        `).join('')}
      </div>
    </div>

    <div class="card">
      <h2 class="card-title"><span>03</span> 제안 서비스 및 기대효과</h2>
      <p style="font-size: 15px; line-height: 1.7; color: #3d3937;">
        고객님께 제안드리는 <strong>${servicesSummaryText}</strong> 솔루션은 단순한 기능 도입을 넘어, 관리 비용 절감과 실시간 데이터 기반의 의사결정 체계를 구축하는 데 핵심적인 역할을 수행할 것입니다.
      </p>
    </div>

    <div class="footer-cta">
      <h3>전문 컨설턴트 상담 안내</h3>
      <p>고객사의 세부 비즈니스 환경에 맞춘 견적 및 인프라 실사 컨설팅을 제공해 드립니다.</p>
      <div style="display: flex; justify-content: center; gap: 12px; flex-wrap: wrap;">
        <a href="mailto:enterprise-sales@lguplus.co.kr?subject=[${encodeURIComponent(clientName || '고객사')}] 서비스 제안 문의" class="btn btn-primary" style="padding: 12px 24px; font-size: 15px;">
          ✉️ 담당 영업대표에게 문의 메일 보내기
        </a>
      </div>
    </div>
  </div>
</body>
</html>`;

  triggerDownload(html, fileName);
}
