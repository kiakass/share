import { BrowserRouter, Routes, Route } from 'react-router-dom';
import CreatorPage from './pages/CreatorPage';
import ViewerPage from './pages/ViewerPage';

export default function App() {
  return (
    <BrowserRouter>
      <div className="min-h-screen bg-[#f4f4ee] font-sans text-[#221714]">
        <Routes>
          <Route path="/" element={<CreatorPage />} />
          <Route path="/view" element={<ViewerPage />} />
        </Routes>
      </div>
    </BrowserRouter>
  );
}
