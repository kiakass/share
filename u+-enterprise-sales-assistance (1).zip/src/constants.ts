import { Product, Industry, CompanySize } from './types';

export const INDUSTRIES: Industry[] = [
  'Retail', 'Platform/IT', 'Education', 'Manufacturing', 'Public', 'Medical', 'Finance'
];

export const SIZES: { label: string; value: CompanySize }[] = [
  { label: '대기업 (Large)', value: 'Large' },
  { label: '중소기업 (Medium)', value: 'Medium' },
  { label: '소상공인 (Small)', value: 'Small' }
];

export const PRODUCTS: Product[] = [
  // 인터넷
  { id: 'I001', name: '비즈넷', description: '기업용 초고속 전용 인터넷 서비스', industries: ['Platform/IT', 'Finance', 'Manufacturing'], sizes: ['Large', 'Medium'], category: '인터넷', iconName: 'Globe' },
  { id: 'I002', name: '비즈온', description: '중소기업을 위한 안정적인 오피스 인터넷', industries: ['Retail', 'Platform/IT', 'Medical'], sizes: ['Medium', 'Small'], category: '인터넷', iconName: 'Globe' },
  { id: 'I003', name: 'U+모바일인터넷', description: '언제 어디서나 간편하게 연결되는 비즈니스 모바일 인터넷', industries: ['Retail', 'Manufacturing'], sizes: ['Small', 'Medium'], category: '인터넷', iconName: 'Network' },
  { id: 'I004', name: '초중고인터넷', description: '학내 전산망에 최적화된 교육용 전용 회선', industries: ['Education'], sizes: ['Large', 'Medium'], category: '인터넷', iconName: 'Globe' },
  { id: 'I005', name: 'PC방넷', description: 'PC방 영업에 최적화된 프리미엄 초고속 인터넷', industries: ['Retail'], sizes: ['Medium', 'Small'], category: '인터넷', iconName: 'Globe' },
  { id: 'I006', name: '와이파이오피스', description: '사무실 전역에 끊김 없는 고품질 무선 네트워크 구축', industries: ['Platform/IT', 'Finance', 'Public'], sizes: ['Small', 'Medium', 'Large'], category: '인터넷', iconName: 'Globe' },
  { id: 'I007', name: '프리미엄와이파이', description: '고객 방문객이 많은 매장을 위한 고용량 와이파이 서비스', industries: ['Retail', 'Medical', 'Public'], sizes: ['Small', 'Medium'], category: '인터넷', iconName: 'Globe' },

  // 전용회선
  { id: 'L001', name: '국내전용회선', description: '본사와 지사를 연결하는 독립된 전용 데이터 통로', industries: ['Manufacturing', 'Finance', 'Public'], sizes: ['Large', 'Medium'], category: '전용회선', iconName: 'Network' },
  { id: 'L002', name: '양자내성암호전용회선', description: '양자 컴퓨터 해킹에 대응하는 차세대 보안 전용회선', industries: ['Finance', 'Public', 'Platform/IT'], sizes: ['Large'], category: '전용회선', iconName: 'Network' },
  { id: 'L003', name: '국제전용회선', description: '글로벌 사업 확장을 위한 고품질 해외 연결망', industries: ['Manufacturing', 'Platform/IT', 'Finance'], sizes: ['Large'], category: '전용회선', iconName: 'Network' },
  { id: 'L004', name: '방송전용회선', description: '실시간 영상 송출 및 방송 제작을 위한 고대역폭 회선', industries: ['Platform/IT', 'Public'], sizes: ['Large', 'Medium'], category: '전용회선', iconName: 'Network' },
  { id: 'L005', name: '공공전용회선', description: '공공기관 및 국가망에 최적화된 안정적인 독립 네트워크', industries: ['Public'], sizes: ['Large', 'Medium'], category: '전용회선', iconName: 'Network' },
  { id: 'L006', name: '대학교육망', description: '대학 캠퍼스의 연구 및 교육 활동을 지원하는 전용망', industries: ['Education'], sizes: ['Large'], category: '전용회선', iconName: 'Network' },
  { id: 'L007', name: '5G전용망', description: '초저지연, 대용량 데이터 처리를 위한 맞춤형 5G 네트워크', industries: ['Manufacturing', 'Platform/IT'], sizes: ['Large', 'Medium'], category: '전용회선', iconName: 'Network' },
  { id: 'L008', name: 'MVP', description: '가상 사설망 기술을 활용한 안전하고 경제적인 전용 통신망', industries: ['Manufacturing', 'Finance'], sizes: ['Large', 'Medium'], category: '전용회선', iconName: 'Network' },

  // 전화
  { id: 'T001', name: 'AI비즈콜', description: 'AI가 전화를 대신 받아 예약을 관리해주는 스마트 비서', industries: ['Retail', 'Medical', 'Platform/IT'], sizes: ['Small', 'Medium'], category: '전화', iconName: 'PhoneCall' },
  { id: 'T002', name: '기업 인터넷전화 일반형', description: '저렴한 비용으로 구축 가능한 고품질 디지털 전화', industries: ['Retail', 'Platform/IT', 'Public'], sizes: ['Small', 'Medium', 'Large'], category: '전화', iconName: 'PhoneCall' },
  { id: 'T003', name: '기업 인터넷전화 교환기설치', description: '자체 교환기 설치를 통한 다양한 부가기능 제공 시스템', industries: ['Manufacturing', 'Platform/IT'], sizes: ['Large', 'Medium'], category: '전화', iconName: 'PhoneCall' },
  { id: 'T004', name: '050전화', description: '비즈니스 채널 홍보 및 마케팅 효과 분석에 최적화된 번호', industries: ['Retail', 'Platform/IT'], sizes: ['Small', 'Medium'], category: '전화', iconName: 'PhoneCall' },
  { id: 'T005', name: '050FAX', description: '종이 없는 사무 환경을 위한 간편한 PC 연동 팩스 서비스', industries: ['Platform/IT', 'Finance', 'Public'], sizes: ['Small', 'Medium', 'Large'], category: '전화', iconName: 'PhoneCall' },
  { id: 'T006', name: '050안심번호', description: '개인정보 보호를 위한 비즈니스용 가상 안심번호 솔루션', industries: ['Retail', 'Platform/IT'], sizes: ['Small', 'Medium'], category: '전화', iconName: 'PhoneCall' },
  { id: 'T007', name: '기업전화(시내/시외전화)', description: '안정적인 통화 품질을 보장하는 비즈니스 전용 일반 유선전화', industries: ['Manufacturing', 'Public', 'Medical'], sizes: ['Large', 'Medium', 'Small'], category: '전화', iconName: 'PhoneCall' },
  { id: 'T008', name: '구내통신', description: '대규모 오피스 및 빌딩을 위한 통합 통신 인프라 구축', industries: ['Manufacturing', 'Public'], sizes: ['Large', 'Medium'], category: '전화', iconName: 'PhoneCall' },
  { id: 'T009', name: '080서비스', description: '고객에게 통화료 부담이 없는 수신자 부담 전화 서비스', industries: ['Retail', 'Medical', 'Public'], sizes: ['Medium', 'Large'], category: '전화', iconName: 'PhoneCall' },
  { id: 'T010', name: '전국대표번호', description: '분산된 매장 및 사무실을 하나의 번호로 연결하는 대표번호', industries: ['Retail', 'Medical', 'Public', 'Finance'], sizes: ['Medium', 'Large'], category: '전화', iconName: 'PhoneCall' },

  // 보안
  { id: 'S001', name: 'AlphaKey', description: '기업 보안의 핵심, 강력한 인증 및 접근 제어 솔루션', industries: ['Platform/IT', 'Finance', 'Public'], sizes: ['Large', 'Medium'], category: '보안', iconName: 'Cctv' },
  { id: 'S002', name: 'U+PQC VPN', description: '양자 내성 암호 적용으로 한 단계 더 진화한 가상 사설망', industries: ['Finance', 'Public', 'Platform/IT'], sizes: ['Large', 'Medium'], category: '보안', iconName: 'Cctv' },
  { id: 'S003', name: 'U+프리미엄보안관제', description: '전문 인력이 24시간 감시하는 빈틈없는 지능형 보안 관제', industries: ['Manufacturing', 'Finance', 'Platform/IT'], sizes: ['Large', 'Medium'], category: '보안', iconName: 'Cctv' },
  { id: 'S004', name: '클라우드보안팩', description: '클라우드 환경에 최적화된 통합 보안 패키지 솔루션', industries: ['Platform/IT', 'Retail', 'Medical'], sizes: ['Medium', 'Large', 'Small'], category: '보안', iconName: 'Cctv' },
  { id: 'S005', name: 'DDoS Safer', description: '대규모 디도스 공격으로부터 비즈니스를 보호하는 방어 시스템', industries: ['Platform/IT', 'Public', 'Finance'], sizes: ['Large', 'Medium'], category: '보안', iconName: 'Cctv' },
  { id: 'S006', name: '문서중앙화', description: '중요 자산인 사내 문서를 중앙 서버에서 안전하게 통합 관리', industries: ['Manufacturing', 'Finance', 'Public'], sizes: ['Large', 'Medium'], category: '보안', iconName: 'Cctv' },
  { id: 'S007', name: '보안 아웃소싱', description: '전문 보안 담당자 없이도 운영 가능한 전문가 위탁 관리 서비스', industries: ['Platform/IT', 'Retail'], sizes: ['Small', 'Medium'], category: '보안', iconName: 'Cctv' },
  { id: 'S008', name: 'SD WAN', description: '소프트웨어 정의 기술로 유연하고 안전하게 관리하는 기업망', industries: ['Retail', 'Platform/IT', 'Manufacturing'], sizes: ['Large', 'Medium'], category: '보안', iconName: 'Cctv' },

  // 모빌리티
  { id: 'M001', name: 'U+커넥트', description: '차량과 비즈니스를 연결하는 통합 커넥티드 카 서비스', industries: ['Manufacturing', 'Retail'], sizes: ['Large', 'Medium'], category: '모빌리티', iconName: 'Truck' },
  { id: 'M002', name: 'U+초정밀측위', description: '센티미터 단위의 오차 없는 실시간 정밀 위치 인식 솔루션', industries: ['Manufacturing', 'Platform/IT'], sizes: ['Large', 'Medium'], category: '모빌리티', iconName: 'Truck' },
  { id: 'M003', name: 'C-ITS', description: '도로 인프라와 차량이 협력하는 지능형 교통 체계 시스템', industries: ['Public'], sizes: ['Large'], category: '모빌리티', iconName: 'Truck' },
  { id: 'M004', name: '자율주행', description: '미래 모빌리티의 핵심, LGU+의 앞선 자율주행 기술 솔루션', industries: ['Manufacturing', 'Platform/IT'], sizes: ['Large'], category: '모빌리티', iconName: 'Truck' },
  { id: 'M005', name: 'U+Drive', description: '차량 내 인포테인먼트 및 스마트 서비스 통합 플랫폼', industries: ['Manufacturing'], sizes: ['Large', 'Medium'], category: '모빌리티', iconName: 'Truck' },

  // 협업솔루션
  { id: 'C001', name: 'U+슈퍼스쿨', description: '학교 행정과 학습을 하나로 연결하는 교육 통합 플랫폼', industries: ['Education'], sizes: ['Large', 'Medium'], category: '협업솔루션', iconName: 'Headset' },
  { id: 'C002', name: '기업메시징', description: '신뢰성 있는 알림톡 및 문자 서비스를 통한 고객 소통 창구', industries: ['Retail', 'Medical', 'Finance'], sizes: ['Small', 'Medium', 'Large'], category: '협업솔루션', iconName: 'Headset' },
  { id: 'C003', name: 'U+메시지허브', description: '전 채널 통합 메시지 발송 인프라 및 관리 시스템', industries: ['Platform/IT', 'Retail'], sizes: ['Medium', 'Large'], category: '협업솔루션', iconName: 'Headset' },
  { id: 'C004', name: 'U+메시지허브이지', description: '복잡한 설정 없이 바로 사용하는 초간편 기업 메시징 솔루션', industries: ['Retail', 'Platform/IT'], sizes: ['Small', 'Medium'], category: '협업솔루션', iconName: 'Headset' },
  { id: 'C005', name: '전자문서', description: '계약부터 공인 전달까지 종이 없는 스마트 비즈니스 실현', industries: ['Finance', 'Public', 'Platform/IT'], sizes: ['Small', 'Medium', 'Large'], category: '협업솔루션', iconName: 'Database' },
  { id: 'C006', name: '얼마에요ERP', description: '경리 회계부터 재고 관리까지 가능한 중소기업용 통합 ERP', industries: ['Retail', 'Manufacturing'], sizes: ['Small', 'Medium'], category: '협업솔루션', iconName: 'Database' },
  { id: 'C007', name: '웹하드™', description: '원조 파일 공유 서비스, 대용량 파일의 안전한 공유와 보관', industries: ['Retail', 'Platform/IT', 'Education'], sizes: ['Small', 'Medium', 'Large'], category: '협업솔루션', iconName: 'Database' },
  { id: 'C008', name: 'U+전자수발주', description: '구매와 납품 업무를 효율적으로 관리하는 통합 SCM 솔루션', industries: ['Manufacturing', 'Retail'], sizes: ['Large', 'Medium'], category: '협업솔루션', iconName: 'Database' },
  { id: 'C009', name: '원격지원', description: '어디서나 원격으로 기술 지원팀의 도움을 받는 고속 원격 제어', industries: ['Platform/IT', 'Medical'], sizes: ['Small', 'Medium', 'Large'], category: '협업솔루션', iconName: 'Database' },
  { id: 'C010', name: '무전원 디지털락', description: '에너지 없이 보안을 지키는 친환경 고성능 잠금 장치 솔루션', industries: ['Manufacturing', 'Public'], sizes: ['Medium', 'Large'], category: '협업솔루션', iconName: 'Database' },
  { id: 'C011', name: '작업자 안전관리', description: 'IoT 기술로 현장 작업자의 상태를 실시간으로 살피는 안전망', industries: ['Manufacturing', 'Public'], sizes: ['Large', 'Medium'], category: '협업솔루션', iconName: 'Cctv' },
  { id: 'C012', name: 'U+스마트안전솔루션', description: '사고 예방을 위한 지능형 센서 기반 통합 현장 안전 시스템', industries: ['Manufacturing', 'Public'], sizes: ['Large', 'Medium'], category: '협업솔루션', iconName: 'Cctv' },

  // 기업 모바일
  { id: 'B001', name: 'LTE Biz요금제', description: '기업 고객의 업무 패턴에 맞춘 고효율 데이터 전용 요금제', industries: ['Retail', 'Manufacturing', 'Platform/IT'], sizes: ['Small', 'Medium', 'Large'], category: '기업 모바일', iconName: 'Network' },
  { id: 'B002', name: 'LTE 비즈프리', description: '사용량만큼 지불하는 합리적인 기업형 후불 전용 데이터 부가 서비스', industries: ['Retail', 'Platform/IT'], sizes: ['Small', 'Medium'], category: '기업 모바일', iconName: 'Network' },
  { id: 'B003', name: '기업한방에yo', description: '결합할수록 커지는 기업용 통신비 절감 패키징 혜택', industries: ['Retail', 'Platform/IT'], sizes: ['Small', 'Medium'], category: '기업 모바일', iconName: 'Network' },
  { id: 'B004', name: 'LTE무전기', description: '스마트폰을 무전기처럼, 전용 LTE망으로 끊김 없는 현장 무전', industries: ['Manufacturing', 'Retail', 'Public'], sizes: ['Medium', 'Large'], category: '기업 모바일', iconName: 'Network' },
  { id: 'B005', name: 'V비즈링', description: '전화를 거는 고객에게 영상과 음악으로 전하는 우리 기업 광고', industries: ['Retail', 'Medical', 'Public'], sizes: ['Small', 'Medium', 'Large'], category: '기업 모바일', iconName: 'Network' },
];

export const COLORS = {
  magenta: '#ff2e98',
  black: '#221714',
  gray: '#82817e',
  lightGray: '#f4f4ee',
  white: '#ffffff',
};

export const INDUSTRY_TRENDS: Record<Industry, string> = {
  Retail: '온·오프라인 경계가 허물어지는 O2O 시장의 확대로 실시간 재고 관리와 지능형 보안 시스템의 중요성이 증대되고 있습니다.',
  'Platform/IT': '클라우드 네이티브 환경으로의 전환과 비대면 협업 툴 도입이 가속화되며 데이터 보안과 안정적인 네트워크가 필수 요소로 자리 잡았습니다.',
  Education: '메타버스 학습 플랫폼과 에듀테크 도입으로 고용량 데이터 전송을 위한 5G 및 고품질 인터넷 회선 수요가 급증하고 있습니다.',
  Manufacturing: '스마트 팩토리 구현을 위한 IoT 센서 데이터 수집과 공정 자동화, 실시간 모니터링을 통한 운영 효율화가 핵심 트렌드입니다.',
  Public: '공공 서비스의 디지털 전환이 가속화됨에 따라 클라우드 기반의 공공망 보안과 대국민 서비스 안정성 확보가 최우선 과제입니다.',
  Medical: '비대면 진료와 환자 데이터의 디지털 자산화가 진행되면서 철저한 보안이 보장되는 클라우드 인프라와 AI 고객 응대 시스템이 각광받고 있습니다.',
  Finance: '비대면 금융 서비스의 신뢰성 확보를 위한 보안 고도화와 고도화된 고객 상담을 위한 클라우드 컨택 센터 도입이 활발합니다.'
};
