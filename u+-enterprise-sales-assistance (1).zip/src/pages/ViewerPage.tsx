import { GoogleGenAI } from "@google/genai";
import React, { useMemo, useState, useEffect } from 'react';
import { useSearchParams } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Play, 
  FileDown, 
  ArrowRight, 
  ChevronDown, 
  CheckCircle2, 
  MessageSquare,
  Network,
  Cctv,
  Truck,
  PhoneCall,
  Headset,
  Globe,
  Database,
  Smartphone,
  ExternalLink,
  ChevronLeft,
  FileText,
  Activity,
  History,
  LayoutGrid,
  ArrowDown,
  Share2
} from 'lucide-react';
import { PRODUCTS, COLORS, INDUSTRY_TRENDS } from '../constants';
import { cn } from '../lib/utils';
import { Industry, CompanySize } from '../types';
import { downloadPrdHtml, downloadProposalHtml } from '../lib/exportHtml';

const CategoryIconMap: Record<string, React.ElementType> = {
  '인터넷': Globe,
  '전용회선': Network,
  '전화': PhoneCall,
  '보안': Cctv,
  '모빌리티': Truck,
  '협업솔루션': Headset,
  '기업 모바일': Smartphone,
};

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

interface ViewerPageProps {
  isPreview?: boolean;
  onBack?: () => void;
  onNavigate?: (page: 'builder' | 'share' | 'preview') => void;
  currentStep?: number;
  previewData?: {
    clientName: string;
    industry: Industry;
    size: CompanySize;
    prodIds: string[];
    dynamicContent?: { trend: string, background: string, products: string[] };
  };
}

export default function ViewerPage({ isPreview, onBack, onNavigate, currentStep, previewData }: ViewerPageProps) {
  const [searchParams] = useSearchParams();
  const [activeProductId, setActiveProductId] = useState<string | null>(null);
  const [isGenerating, setIsGenerating] = useState(false);
  const [dynamicContent, setDynamicContent] = useState<{ trend: string, background: string, products: string[] } | null>(null);

  const clientName = previewData?.clientName || searchParams.get('comp') || '';
  const industry = (previewData?.industry || searchParams.get('industry') || 'Manufacturing') as Industry;
  const size = (previewData?.size || searchParams.get('size') || 'Large') as CompanySize;
  const prodIds = previewData?.prodIds || searchParams.get('prods')?.split(',') || [];

  const proposedProducts = useMemo(() => {
    // URL이나 previewData에서 명시적으로 전달된 상품 ID가 있으면 그것을 우선 사용
    // AI가 생성한 추천은 상품 ID가 전달되지 않았을 때만 폴백으로 사용
    const ids = prodIds.length > 0 
      ? prodIds 
      : (dynamicContent?.products && dynamicContent.products.length > 0 ? dynamicContent.products : []);
    
    return PRODUCTS.filter(p => ids.includes(p.id));
  }, [prodIds, dynamicContent]);

  const curatedProducts = useMemo(() => [...proposedProducts], [proposedProducts]);

  const groupedProposed = useMemo(() => {
    const groups: Record<string, typeof proposedProducts> = {};
    proposedProducts.forEach(p => {
      if (!groups[p.category]) groups[p.category] = [];
      groups[p.category].push(p);
    });
    return groups;
  }, [proposedProducts]);

  const activeProduct = useMemo(() => {
    return curatedProducts.find(p => p.id === activeProductId) || proposedProducts[0];
  }, [activeProductId, curatedProducts, proposedProducts]);

  useEffect(() => {
    // If previewData includes dynamicContent, use it and skip generation
    if (previewData?.dynamicContent) {
      setDynamicContent(previewData.dynamicContent);
      return;
    }

    const generateAnalysis = async () => {
      if (!clientName || !industry || !size) return;
      
      setIsGenerating(true);
      try {
        const productData = PRODUCTS.map(p => `${p.id}: ${p.name} (${p.category} - ${p.description})`).join('\n');
        
        const prompt = `당신은 LGU+의 지능형 비즈니스 솔루션 전문가입니다.
고객 정보: 고객사명($\{clientName\}), 업종($\{industry\}), 규모($\{size\})

다음 태스크를 수행하고 반드시 JSON 형식으로 응답하세요:
1. 시장 분석(trend): 해당 업종의 최신 시장 변화와 디지털 전환 동향 (2문장 내외, 한국어)
2. 실시간 상품 추천(productIds): 아래 제공된 LGU+ 상품 목록 중 이 고객에게 가장 필수적인 상품의 ID 리스트를 선정하세요 (최대 10개 내외).
3. 제안 배경(background): 추천한 상품들이 고객사의 Pain Point를 어떻게 해결하고 어떤 가치를 주는지 요약 (3문장 내외, 한국어)

LGU+ 상품 목록:
$\{productData\}

응답 JSON 구조:
{
  "trend": "시장 분석 내용",
  "productIds": ["ID1", "ID2", "ID3", "..."],
  "background": "제안 배경 내용"
}`;

        const response = await ai.models.generateContent({
          model: "gemini-3-flash-preview",
          contents: prompt,
          config: {
            responseMimeType: "application/json",
          }
        });

        const result = JSON.parse(response.text || '{}');

        setDynamicContent({
          trend: result.trend || INDUSTRY_TRENDS[industry as Industry],
          products: Array.isArray(result.productIds) ? result.productIds : [],
          background: result.background || ""
        });
      } catch (error) {
        console.error("AI Generation failed:", error);
      } finally {
        setIsGenerating(false);
      }
    };

    generateAnalysis();
  }, [clientName, industry, size, previewData?.dynamicContent]);

  if (curatedProducts.length === 0) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-[#f4f4ee]">
        <div className="text-center space-y-4">
          <p className="text-[#82817e]">선택된 상품이 없거나 링크가 올바르지 않습니다.</p>
          <a href="/" className="text-[#ff2e98] font-bold underline">메인으로 돌아가기</a>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#f4f4ee] text-[#221714] flex flex-col">
      {/* Top Navigation Bar (Only for Preview mode) */}
      {isPreview && (
        <header className="h-16 lg:h-20 bg-[#1a1715] text-white flex items-center justify-between px-4 lg:px-8 sticky top-0 z-[60] shrink-0">
          <div className="flex items-center gap-4 lg:gap-8 overflow-hidden">
            <div className="flex items-center gap-3 shrink-0">
               <div className="w-8 h-8 lg:w-10 lg:h-10 bg-[#ff2e98] rounded-lg lg:rounded-xl flex items-center justify-center shadow-lg shadow-[#ff2e98]/20 text-white font-black italic">
                 <span className="text-sm lg:text-base">U+</span>
               </div>
               <div className="hidden sm:flex flex-col -space-y-0.5">
                 <span className="font-black text-sm lg:text-lg tracking-tighter">Enterprise</span>
                 <span className="text-[8px] lg:text-[10px] text-white/40 font-bold uppercase tracking-widest">Sales Assistant</span>
               </div>
            </div>

            <nav className="flex items-center gap-4 lg:gap-10 h-full overflow-x-auto no-scrollbar whitespace-nowrap">
              {[
                { id: 'builder', label: 'Proposal Builder', isActive: false, onClick: () => onNavigate?.('builder') },
                { id: 'preview', label: 'Preview', isActive: true, onClick: () => {} },
                { id: 'share', label: 'Share', isActive: false, onClick: () => onNavigate?.('share') },
              ].map((item) => (
                <button 
                  key={item.id}
                  onClick={item.onClick}
                  className={cn(
                    "text-xs lg:text-sm font-bold tracking-tight transition-all relative h-full px-2 flex items-center shrink-0",
                    item.isActive ? "text-white" : "text-white/40 hover:text-white/60"
                  )}
                >
                  {item.label}
                  {item.isActive && (
                    <motion.div layoutId="nav-active" className="absolute bottom-0 left-0 right-0 h-1 bg-[#ff2e98] rounded-t-full shadow-[0_-4px_12px_rgba(255,46,152,0.4)]" />
                  )}
                </button>
              ))}
            </nav>
          </div>

          <div className="flex items-center gap-2 lg:gap-3 shrink-0">
            <button
              onClick={() => downloadProposalHtml({
                clientName,
                industry,
                size,
                prodIds: proposedProducts.map(p => p.id),
                dynamicContent
              })}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#ff2e98] hover:bg-[#ff2e98]/90 text-white text-xs font-bold transition-all shadow-sm"
              title="제안서를 독립 실행 가능한 HTML 파일로 다운로드합니다"
            >
              <FileDown className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">제안서 HTML 다운로드</span>
              <span className="sm:hidden">HTML</span>
            </button>
            <button
              onClick={() => downloadPrdHtml()}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-white text-xs font-bold transition-all border border-white/10"
              title="최신 PRD 문서를 HTML 파일로 다운로드합니다"
            >
              <FileText className="w-3.5 h-3.5 text-[#ff2e98]" />
              <span className="hidden sm:inline">PRD HTML</span>
              <span className="sm:hidden">PRD</span>
            </button>
          </div>
        </header>
      )}

      <div className="flex-1">
        {/* Navigation / Header (Customer-facing) */}
        {!isPreview && (
          <header className="sticky top-0 z-50 bg-[#f4f4ee]/80 backdrop-blur-md border-b border-black/5 px-6 py-4">
            <div className="max-w-6xl mx-auto flex justify-between items-center">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 bg-[#ff2e98] rounded-lg flex items-center justify-center">
                  <div className="w-4 h-4 text-white font-black italic">U+</div>
                </div>
                <span className="font-black tracking-tighter text-lg">Compass</span>
                <span className="text-sm font-black tracking-tighter uppercase ml-4 text-[#82817e] border-l border-black/10 pl-4">{clientName ? `${clientName} 전용 커스텀 제안` : "커스텀 제안"}</span>
              </div>
              <div className="flex items-center gap-2">
                <button 
                  onClick={() => downloadProposalHtml({
                    clientName,
                    industry,
                    size,
                    prodIds: proposedProducts.map(p => p.id),
                    dynamicContent
                  })}
                  className="text-xs font-bold text-[#ff2e98] hover:bg-[#ff2e98]/5 transition-colors border border-[#ff2e98]/30 px-3.5 py-2 rounded-full flex items-center gap-1.5 bg-white shadow-sm"
                  title="제안서를 HTML 파일로 다운로드"
                >
                  <FileDown className="w-3.5 h-3.5" />
                  <span>HTML 다운로드</span>
                </button>
                <button className="text-xs font-bold text-[#82817e] hover:text-[#ff2e98] transition-colors border border-black/10 px-4 py-2 rounded-full">
                  영업 담당자 문의
                </button>
              </div>
            </div>
          </header>
        )}

        {/* Hero Section */}
        <section className="px-6 pt-12 lg:pt-24 pb-4 lg:pb-6 overflow-hidden relative">
          <div className="max-w-6xl mx-auto relative z-10 text-center">
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="space-y-4 lg:space-y-6"
            >
              <div className="inline-flex items-center gap-2 px-4 py-1 rounded-full bg-white border border-[#ff2e98]/20 shadow-sm mx-auto">
                <span className="w-2 h-2 rounded-full bg-[#ff2e98] animate-pulse" />
                <span className="text-[9px] lg:text-[10px] font-bold text-[#ff2e98] uppercase tracking-widest">Personalized Offer</span>
              </div>
              <h1 className="text-3xl lg:text-6xl font-black tracking-tighter leading-tight flex items-center justify-center gap-3 lg:gap-5 flex-wrap">
                <span>{clientName ? `${clientName} 고객님을 위한` : "고객님을 위한"}</span>
                <br className="lg:hidden" />
                <div className="flex items-center gap-3 lg:gap-4">
                  <span className="text-[#ff2e98]">맞춤 서비스 소개</span>
                  <button 
                    onClick={() => downloadProposalHtml({
                      clientName,
                      industry,
                      size,
                      prodIds: proposedProducts.map(p => p.id),
                      dynamicContent
                    })}
                    className="p-3 lg:p-4 bg-white border-2 border-black/5 rounded-xl lg:rounded-2xl hover:bg-[#ff2e98] hover:text-white hover:border-[#ff2e98] transition-all shadow-sm group"
                    title="제안서 HTML 파일 다운로드"
                  >
                    <FileDown className="w-5 h-5 lg:w-8 lg:h-8 group-hover:scale-110 transition-transform" />
                  </button>
                  <button 
                    onClick={() => onNavigate?.('share')}
                    className="p-3 lg:p-4 bg-white border-2 border-black/5 rounded-xl lg:rounded-2xl hover:bg-black hover:text-white hover:border-black transition-all shadow-sm group"
                    title="제안서 공유하기"
                  >
                    <Share2 className="w-5 h-5 lg:w-8 lg:h-8 group-hover:scale-110 transition-transform" />
                  </button>
                </div>
              </h1>
              {clientName && (
                <div className="flex items-center justify-center gap-3 lg:gap-4 text-xs lg:text-sm font-bold text-[#82817e]">
                   <span className="whitespace-nowrap">업종: <span className="text-[#221714]">{industry}</span></span>
                   <span className="w-1 h-1 rounded-full bg-[#82817e]/30" />
                   <span className="whitespace-nowrap">규모: <span className="text-[#221714]">{size}</span></span>
                </div>
              )}
            </motion.div>
          </div>
        </section>
        {/* Sophisticated Separator */}
        <div className="max-w-6xl mx-auto px-6 py-6">
          <div className="relative flex items-center">
            <div className="flex-grow border-t border-black/5"></div>
            <div className="flex-shrink flex gap-2 mx-8 items-center">
              <div className="w-1 h-1 rounded-full bg-[#ff2e98]/40" />
              <div className="w-12 h-px bg-[#ff2e98]/20" />
              <div className="w-1 h-1 rounded-full bg-[#ff2e98]/40" />
            </div>
            <div className="flex-grow border-t border-black/5"></div>
          </div>
        </div>

        {/* Industry Trends & Proposal Overview - Refined Glass Section */}
        <section className="px-6 pb-12">
          <div className="max-w-6xl mx-auto">
             <motion.div 
               initial={{ opacity: 0, y: 30 }}
               animate={{ opacity: 1, y: 0 }}
               transition={{ delay: 0.2 }}
               className="bg-white rounded-3xl p-6 lg:p-12 shadow-xl shadow-black/[0.02] border border-black/[0.03] overflow-hidden relative"
             >
                <div className="relative z-10">
                  <div className="space-y-8 lg:space-y-10">
                    {/* Market Trends */}
                    <div className="space-y-4">
                      <div className="flex items-center gap-3">
                        <div className="w-1 h-4 bg-[#ff2e98] rounded-full" />
                        <h3 className="text-lg font-black tracking-tight text-[#1a1715]">
                          {clientName ? "시장 분석 및 업계 동향" : "고객 감사 메시지"}
                        </h3>
                      </div>
                      
                      <div className="relative pl-5">
                        {isGenerating ? (
                          <div className="space-y-3 animate-pulse">
                            <div className="h-6 bg-black/5 rounded w-full"></div>
                            <div className="h-6 bg-black/5 rounded w-4/5"></div>
                          </div>
                        ) : clientName ? (
                          <p className="text-lg lg:text-xl font-bold text-[#1a1715] leading-[1.5] tracking-tight italic">
                            "{dynamicContent?.trend || INDUSTRY_TRENDS[industry as Industry]}"
                          </p>
                        ) : (
                          <p className="text-lg lg:text-xl font-bold text-[#1a1715] leading-[1.5] tracking-tight italic">
                            "LGU+의 비즈니스 솔루션을 검토해주셔서 진심으로 감사드립니다. 고객사의 성공적인 비즈니스를 지원하기 위해 최적의 서비스 구성안을 제안합니다."
                          </p>
                        )}
                      </div>
                    </div>

                    {/* Proposal Background */}
                    <div className="pt-8 border-t border-black/[0.1] border-dashed space-y-4">
                      <div className="flex items-center gap-3">
                        <div className="w-1 h-4 bg-black/20 rounded-full" />
                        <h3 className="text-lg font-black tracking-tight text-[#1a1715]">제안 서비스 및 기대효과</h3>
                      </div>
                      
                      <div className="text-[#82817e] text-sm lg:text-[15px] leading-relaxed space-y-3 font-medium">
                        {isGenerating ? (
                          <div className="space-y-3 animate-pulse">
                            <div className="h-4 bg-black/5 rounded w-full"></div>
                            <div className="h-4 bg-black/5 rounded w-full"></div>
                            <div className="h-4 bg-black/5 rounded w-3/4"></div>
                          </div>
                        ) : (
                          <>
                            {!(industry === 'Manufacturing' && size === 'Large') && (
                              <p>
                                {clientName ? (
                                  <><span className="text-[#ff2e98] font-black">{clientName}</span> 고객사의 </>
                                ) : (
                                  <>고객사의 </>
                                )}
                                <span className="text-[#1a1715] font-black ml-1 whitespace-nowrap">{industry}</span> 업종 특성과 
                                <span className="text-[#1a1715] font-black ml-1 whitespace-nowrap">{size}</span> 규모의 운영 효율성을 분석한 결과, 
                                디지털 전환을 통한 인프라 고도화가 최우선 과제로 파악되었습니다.
                              </p>
                            )}
                            <p>
                              {!(industry === 'Manufacturing' && size === 'Large') ? (
                                <>특히 제안드리는 <span className="text-[#1a1715] font-black italic underline decoration-[#ff2e98]/30 decoration-4 underline-offset-4">
                                  {proposedProducts.length > 5 
                                    ? proposedProducts.slice(0, 5).map(p => p.name).join(', ') + ', ...' 
                                    : proposedProducts.map(p => p.name).join(', ')}
                                </span> 솔루션은 </>
                              ) : (
                                <>{clientName ? (
                                  <><span className="text-[#ff2e98] font-black">{clientName}</span> 고객님께 제안드리는 </>
                                ) : (
                                  <>고객님께 제안드리는 </>
                                )} <span className="text-[#1a1715] font-black italic underline decoration-[#ff2e98]/30 decoration-4 underline-offset-4">
                                  {proposedProducts.length > 5 
                                    ? proposedProducts.slice(0, 5).map(p => p.name).join(', ') + ', ...' 
                                    : proposedProducts.map(p => p.name).join(', ')}
                                </span> 솔루션은 </>
                              )}
                              단순한 기능 도입을 넘어, 관리 비용 절감과 실시간 데이터 기반의 의사결정 체계를 구축하는 데 핵심적인 역할을 수행할 것입니다.
                            </p>
                            {dynamicContent?.background && (
                              <div className="mt-8 p-6 bg-[#f4f4f0] rounded-xl border border-black/[0.03]">
                                <p className="text-[11px] font-black tracking-widest text-[#82817e] uppercase mb-2">AI Consultant Insights</p>
                                <p className="text-sm font-bold text-[#1a1715]/80 leading-relaxed italic">
                                  {dynamicContent.background}
                                </p>
                              </div>
                            )}
                          </>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
             </motion.div>
          </div>
        </section>

        {/* Sophisticated Separator */}
        <div className="max-w-6xl mx-auto px-6 py-6">
          <div className="relative flex items-center">
            <div className="flex-grow border-t border-black/5"></div>
            <div className="flex-shrink flex gap-2 mx-8 items-center">
              <div className="w-1 h-1 rounded-full bg-[#ff2e98]/40" />
              <div className="w-12 h-px bg-[#ff2e98]/20" />
              <div className="w-1 h-1 rounded-full bg-[#ff2e98]/40" />
            </div>
            <div className="flex-grow border-t border-black/5"></div>
          </div>
        </div>

        {/* Product Selection Grid */}
        <section className="px-6 pb-12">
          <div className="max-w-6xl mx-auto space-y-20">
            
            {/* Section: Proposed Products */}
            <div className="space-y-10">
               <div className="flex items-center gap-3">
                   <div className="w-2 h-2 rounded-full bg-[#ff2e98]" />
                   <h3 className="text-sm font-black uppercase tracking-[0.2em] text-[#ff2e98]">추천 및 제안 서비스</h3>
                </div>
              
              <div className="space-y-16">
                {(Object.entries(groupedProposed) as [string, typeof proposedProducts][]).map(([category, products]) => (
                  <div key={category} className="space-y-6">
                    <div className="flex items-center gap-3">
                      <div className="w-1 h-4 bg-black/10 rounded-full" />
                      <h4 className="text-sm font-black text-[#1a1715]">{category}</h4>
                    </div>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                      {products.map((prod, idx) => {
                        const Icon = CategoryIconMap[prod.category] || Network;
                        const isActive = activeProduct.id === prod.id;

                        return (
                          <motion.button
                            key={prod.id}
                            initial={{ opacity: 0, y: 10 }}
                            animate={{ opacity: 1, y: 0 }}
                            transition={{ delay: idx * 0.05 }}
                            onClick={() => setActiveProductId(prod.id)}
                            className={cn(
                              "relative group p-5 lg:p-6 rounded-2xl border transition-all text-left overflow-hidden flex flex-col justify-between h-full min-h-[120px]",
                              isActive 
                                ? "bg-[#221714] text-white border-transparent shadow-xl shadow-[#ff2e98]/10" 
                                : "bg-white text-[#221714] border-[#82817e]/10 hover:border-[#ff2e98]/30"
                            )}
                          >
                            <div className="relative z-10 space-y-3">
                              <div className="flex items-center gap-3">
                                <div className={cn(
                                  "w-10 h-10 rounded-lg flex items-center justify-center transition-colors",
                                  isActive ? "bg-[#ff2e98] text-white" : "bg-[#f4f4ee] text-[#ff2e98] group-hover:bg-[#ff2e98] group-hover:text-white"
                                )}>
                                  <Icon className="w-5 h-5" />
                                </div>
                                <h3 className="text-base font-bold leading-tight">{prod.name}</h3>
                              </div>
                              <p className={cn(
                                "text-xs leading-relaxed line-clamp-2 font-medium opacity-80",
                                isActive ? "text-white/70" : "text-[#82817e]"
                              )}>
                                {prod.description}
                              </p>
                            </div>
                            {isActive && (
                              <div className="mt-2 flex items-center gap-1">
                                <span className="w-1 h-1 rounded-full bg-[#ff2e98]" />
                                <span className="text-[9px] font-bold text-[#ff2e98] uppercase">Selected</span>
                              </div>
                            )}
                          </motion.button>
                        );
                      })}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Detailed Section */}
            <AnimatePresence mode="wait">
              <motion.div
                key={activeProduct.id}
                initial={{ opacity: 0, scale: 0.98 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.98 }}
                className="bg-white rounded-3xl p-8 lg:p-14 border border-[#82817e]/10 shadow-xl overflow-hidden relative"
              >
                <div className="space-y-12 relative z-10">
                  <div>
                    <span className="text-[10px] font-bold text-[#ff2e98] uppercase tracking-[0.2em] mb-4 block">Product Highlight</span>
                  <div className="mb-6 flex flex-col md:flex-row md:items-baseline gap-3 md:gap-5">
                    <h2 className="text-4xl lg:text-5xl font-black tracking-tighter text-[#1a1715]">{activeProduct.name}</h2>
                    <span className="text-sm lg:text-base font-bold text-[#82817e]">{activeProduct.description}</span>
                  </div>
                    <p className="text-lg text-[#82817e] leading-relaxed font-medium max-w-4xl">
                      {activeProduct.longDescription}
                    </p>
                  </div>

                  <div className="grid lg:grid-cols-12 gap-10 lg:gap-16 items-stretch">
                    <div className="lg:col-span-7">
                      <div className="aspect-video bg-[#221714] rounded-2xl overflow-hidden shadow-2xl relative group border-[6px] border-[#f4f4ee] h-full">
                        <iframe
                          width="100%"
                          height="100%"
                          src="https://www.youtube.com/embed/ekXkxalTXU8"
                          title="YouTube video player"
                          frameBorder="0"
                          allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                          allowFullScreen
                        ></iframe>
                      </div>
                    </div>

                    <div className="lg:col-span-5 flex flex-col justify-between h-full">
                      <div className="grid grid-cols-2 gap-4">
                        <a 
                          href="https://youtu.be/ekXkxalTXU8?si=BbXNI6M0Owb5oGKt" 
                          target="_blank" 
                          rel="noopener noreferrer"
                          className="flex items-center justify-between p-5 bg-[#1a1715] text-white rounded-lg hover:bg-[#ff2e98] transition-all group shadow-sm h-[72px]"
                        >
                            <div className="flex items-center gap-3">
                              <Play className="w-4 h-4 fill-white" />
                              <span className="font-bold text-sm">소개 영상</span>
                            </div>
                            <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform opacity-60" />
                        </a>
                        <a 
                          href="https://www.lguplus.com/uhdc/fo/fcmm/comm/file/v1?policy=public-file&filePath=%2Fuhdc%2Fcusp%2Fanpd%2F&fileName=20260416-052156-655-DfSio568.pdf&fileOrginName=AlphaKey_%EB%B8%8C%EB%A1%9C%EC%8A%88%EC%96%B4.pdf" 
                          target="_blank" 
                          rel="noopener noreferrer"
                          className="flex items-center justify-between p-5 bg-white border border-black/10 rounded-lg hover:border-[#ff2e98]/30 transition-all group shadow-sm h-[72px]"
                        >
                            <div className="flex items-center gap-3">
                              <FileDown className="w-4 h-4 text-[#ff2e98]" />
                              <span className="font-bold text-sm text-[#1a1715]">브로슈어</span>
                            </div>
                            <ArrowRight className="w-4 h-4 text-[#ff2e98]/40 group-hover:translate-x-1 transition-transform" />
                        </a>
                      </div>

                      <div className="flex flex-col gap-3 h-full justify-end mt-4">
                          {[
                            { title: '블로그 (고객 성공사례) - DX 도입 후 운영 효율 30% 개선', icon: CheckCircle2, url: 'https://www.lguplus.com/biz/insight/story/467' },
                            { title: '보도자료 - LGU+, 중소기업 맞춤형 지능형 비즈니스 솔루션 강화', icon: Globe, url: 'https://www.lguplus.com/biz/insight/trend/758' },
                            { title: '뉴스레터 - 2024 B2B 테크 트렌드: AI와 자동화의 결합', icon: MessageSquare, url: 'https://www.lguplus.com/biz/insight/news/464' }
                          ].map((asset, i) => (
                           <a 
                             key={i} 
                             href={asset.url}
                             target="_blank"
                             rel="noopener noreferrer"
                             className="flex items-center justify-between p-4 bg-[#f4f4f0] rounded-xl border border-transparent hover:bg-white hover:border-[#ff2e98]/20 hover:shadow-lg transition-all cursor-pointer group h-[72px] flex-none"
                           >
                              <div className="flex items-center gap-3">
                                <div className="w-9 h-9 rounded-lg bg-white flex items-center justify-center shadow-sm">
                                   <asset.icon className="w-4 h-4 text-[#82817e] group-hover:text-[#ff2e98] transition-colors" />
                                </div>
                                <span className="font-bold text-sm text-[#1a1715] line-clamp-1">{asset.title}</span>
                              </div>
                              <ArrowRight className="w-4 h-4 text-black/10 group-hover:text-[#ff2e98] transition-all shrink-0" />
                           </a>
                         ))}
                      </div>
                    </div>
                  </div>

                  {/* Service Core Value - Revised Layout */}
                  <motion.div 
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.3 }}
                    className="p-10 lg:p-14 bg-[#f4f4ee] rounded-3xl border border-black/[0.03] relative overflow-hidden"
                  >
                    <div className="absolute top-0 right-0 p-8">
                       <div className="px-5 py-2 bg-[#ff2e98] text-white rounded-full text-[10px] font-black tracking-widest uppercase">LGU+ Verified</div>
                    </div>
                    
                    <div className="grid lg:grid-cols-3 gap-12 items-start relative z-10">
                      <div className="space-y-4">
                        <div className="flex items-center gap-3">
                           <div className="w-10 h-10 rounded-full bg-[#ff2e98]/10 flex items-center justify-center">
                              <Activity className="w-5 h-5 text-[#ff2e98]" />
                           </div>
                           <h4 className="text-2xl font-black text-[#1a1715] tracking-tighter">서비스 핵심 가치</h4>
                        </div>
                        <p className="text-[#82817e] font-medium leading-relaxed">
                          "{activeProduct.description} 서비스를 통해 {industry} 시장에서의 경쟁력을 한 단계 더 높여보세요."
                        </p>
                      </div>

                      <div className="lg:col-span-2 grid grid-cols-1 md:grid-cols-2 gap-10">
                        <div className="space-y-4">
                           <div className="flex items-center gap-3">
                             <div className="w-2 h-2 rounded-full bg-[#ff2e98]" />
                             <p className="text-sm font-black text-[#1a1715] uppercase tracking-widest">Efficiency & ROI</p>
                           </div>
                           <p className="text-base text-[#82817e] font-medium leading-relaxed">
                             {activeProduct.name} 솔루션 도입을 통해 업무 프로세스를 자동화하고 기존 대비 최대 30% 이상의 운영 비용 절감 효과를 기대할 수 있습니다.
                           </p>
                        </div>
                        <div className="space-y-4">
                           <div className="flex items-center gap-3">
                             <div className="w-2 h-2 rounded-full bg-[#ff2e98]" />
                             <p className="text-sm font-black text-[#1a1715] uppercase tracking-widest">Scalable Infra</p>
                           </div>
                           <p className="text-base text-[#82817e] font-medium leading-relaxed">
                             {size} 규모 비즈니스 성장에 맞춰 유연하게 확장 가능한 인프라를 제공하며, 중단 없는 실시간 데이터 처리를 지원합니다.
                           </p>
                        </div>
                      </div>
                    </div>

                    <div className="mt-12 pt-10 border-t border-black/5">
                       <div className="flex flex-col sm:flex-row items-center justify-between gap-6">
                          <p className="text-base lg:text-lg text-[#1a1715]/80 font-black italic max-w-2xl">
                             "24시간 실시간 관제와 전문 기술 지원으로 안정적인 비즈니스 환경을 약속합니다."
                          </p>
                          <button className="whitespace-nowrap px-10 py-5 bg-[#ff2e98] text-white rounded-lg font-black hover:shadow-2xl hover:shadow-[#ff2e98]/30 transition-all text-lg min-w-[240px]">
                            상담 신청 및 견적 문의
                          </button>
                       </div>
                    </div>
                  </motion.div>
                </div>
              </motion.div>
            </AnimatePresence>
          </div>
        </section>

        {/* Related Assets Section */}
        <section className="bg-white py-32 px-6 text-[#221714] overflow-hidden relative border-t border-black/[0.03]">
           <div className="max-w-6xl mx-auto space-y-20 relative z-10">
              <div className="text-center space-y-6">
                 <div className="inline-flex items-center gap-3 px-4 py-1.5 rounded-full bg-[#f4f4f0] border border-black/5">
                    <LayoutGrid className="w-4 h-4 text-[#ff2e98]" />
                    <span className="text-[10px] font-black uppercase tracking-widest text-[#1a1715]">Resource Center</span>
                 </div>
                 <h2 className="text-4xl lg:text-5xl font-black tracking-tighter text-[#1a1715]">Marketing Library</h2>
                 <p className="text-[#82817e] max-w-xl mx-auto font-medium lg:text-lg">
                   성공 사례와 보도자료를 통해 LGU+의 <br className="hidden sm:block" /> 독보적인 기술력을 지금 확인해보세요.
                 </p>
              </div>

              <div className="grid md:grid-cols-3 gap-8">
                 {[
                   { title: '블로그 (성공사례) - 스마트 팩토리 전환기', desc: '비즈니스 인사이트 및 고객 성공 스토리', date: '2024.04', url: 'https://www.lguplus.com/biz/insight/story/467' },
                   { title: '주요 보도 자료 - AX 인프라의 미래', desc: 'LGU+ B2B 솔루션 최신 소식 및 트렌드', date: '2024.04', url: 'https://www.lguplus.com/biz/insight/trend/758' },
                   { title: '뉴스레터 - 비즈니스 맞춤형 테크 리포트', desc: '매월 발행되는 비즈니스 맞춤형 테크 리포트', date: '2024.04', url: 'https://www.lguplus.com/biz/insight/news/464' },
                 ].map((asset, i) => (
                   <a 
                     key={i} 
                     href={asset.url}
                     target="_blank"
                     rel="noopener noreferrer"
                     className="group p-10 rounded-2xl bg-[#f8f8f5] border border-transparent hover:bg-white hover:shadow-2xl hover:shadow-black/[0.04] hover:border-[#ff2e98]/10 transition-all duration-500 cursor-pointer flex flex-col justify-between min-h-[340px]"
                   >
                      <div>
                        <div className="flex justify-between items-start mb-12">
                          <div className="text-[10px] font-black uppercase tracking-widest text-[#ff2e98] bg-white px-4 py-1.5 rounded-full shadow-sm border border-black/5">Report</div>
                          <div className="w-10 h-10 rounded-full bg-white border border-black/5 flex items-center justify-center group-hover:bg-[#ff2e98] group-hover:text-white transition-all duration-300">
                             <ExternalLink className="w-4 h-4 text-black/20 group-hover:text-white" />
                          </div>
                        </div>
                        <h4 className="text-2xl font-black mb-4 text-[#1a1715] tracking-tighter leading-tight group-hover:text-[#ff2e98] transition-colors">{asset.title}</h4>
                        <p className="text-[#82817e] text-base font-medium leading-relaxed">{asset.desc}</p>
                      </div>
                      
                      <div className="pt-8 mt-8 border-t border-black/[0.03] flex items-center justify-between">
                        <div className="flex items-center gap-2 text-[10px] font-black text-black/20 uppercase tracking-widest">
                           <span>LGU+ Corporate</span>
                           <span className="w-1 h-1 rounded-full bg-black/10" />
                           <span>{asset.date}</span>
                        </div>
                        <ArrowRight className="w-5 h-5 text-black/5 -translate-x-2 opacity-0 group-hover:translate-x-0 group-hover:opacity-100 group-hover:text-[#ff2e98] transition-all duration-300" />
                      </div>
                   </a>
                 ))}
              </div>

              <div className="pt-20 text-center">
                 <div className="relative inline-block">
                    <div className="absolute inset-x-0 -bottom-1 h-2 bg-[#ff2e98]/5 rounded-full" />
                    <p className="relative text-xs text-[#82817e]/40 uppercase tracking-[0.4em] font-black">U+ Biz-Sales Compass © 2026</p>
                 </div>
              </div>
           </div>
        </section>
      </div>
    </div>
  );
}
