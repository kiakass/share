import { GoogleGenAI } from "@google/genai";
import React, { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Building2, 
  ChevronRight, 
  ChevronDown,
  Plus, 
  Minus, 
  Share2, 
  Copy, 
  ExternalLink,
  ChevronLeft,
  PanelLeftOpen,
  PanelLeftClose,
  LayoutGrid,
  Settings2,
  Check,
  Send,
  Mail,
  Network,
  Cctv,
  Truck,
  PhoneCall,
  Headset,
  Globe,
  Database,
  Smartphone,
  ArrowRight,
  FileDown,
  FileText
} from 'lucide-react';
import { INDUSTRIES, SIZES, PRODUCTS, COLORS } from '../constants';
import { Industry, CompanySize, Product } from '../types';
import { cn } from '../lib/utils';
import { downloadPrdHtml, downloadProposalHtml } from '../lib/exportHtml';
import ViewerPage from './ViewerPage';

const CategoryIconMap: Record<string, React.ElementType> = {
  '인터넷': Globe,
  '전용회선': Network,
  '전화': PhoneCall,
  '보안': Cctv,
  '모빌리티': Truck,
  '협업솔루션': Headset,
  '기업 모바일': Smartphone,
};

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

export default function CreatorPage() {
  const [step, setStep] = useState(1);
  const [clientName, setClientName] = useState('');
  const [selectedIndustry, setSelectedIndustry] = useState<Industry>('Manufacturing');
  const [selectedSize, setSelectedSize] = useState<CompanySize>('Large');
  const [proposedProducts, setProposedProducts] = useState<string[]>([]);
  const [isCopied, setIsCopied] = useState(false);
  const [isEmailModalOpen, setIsEmailModalOpen] = useState(false);
  const [isPreviewing, setIsPreviewing] = useState(false);
  const [hasBuilt, setHasBuilt] = useState(false);
  const [isAiLoading, setIsAiLoading] = useState(false);
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [introProductId, setIntroProductId] = useState<string | null>(null);
  const [expandedCategories, setExpandedCategories] = useState<string[]>(['인터넷']);
  const [aiInsight, setAiInsight] = useState<string>('업종과 규모를 선택하시면 AI가 최적의 제안 통찰을 제공합니다.');
  const [proposalContent, setProposalContent] = useState<{ trend: string, background: string, products: string[] } | null>(null);
  const [lastAnalyzedName, setLastAnalyzedName] = useState<string>('');

  // Auto-recommendation logic
  const recommendedProducts = useMemo(() => {
    return PRODUCTS.filter(p => 
      p.industries.includes(selectedIndustry) && 
      p.sizes.includes(selectedSize)
    ).slice(0, 5);
  }, [selectedIndustry, selectedSize]);

  // Initial recommendation effect: add recommended ones when segment changes
  const handleAutoCuration = async () => {
    setIsAiLoading(true);
    
    try {
      const productList = PRODUCTS.map(p => `${p.id}: ${p.name} (${p.category} - ${p.description})`).join('\n');
      const prompt = `당신은 LGU+의 B2B 솔루션 컨설턴트 및 지능형 비즈니스 솔루션 전문가입니다. 
고객 정보: 고객사명(${clientName || '미지정'}), 업종(${selectedIndustry}), 규모(${selectedSize})

다음 태스크를 수행하고 반드시 JSON 형식으로 응답하세요:
1. "recommendedProductIds": 이 고객에게 최적인 상품 ID Top 5 리스트.
2. "insight": 이 산업군과 고객 규모에 맞는 짧은 AI 인사이트 문장 (예: "매유 업종 대기업은 ~ 도입 시 효율이 ~% 향상됩니다.")
3. "trend": 해당 업종의 최신 시장 변화와 디지털 전환 동향 (2문장 내외)
4. "background": 추천한 상품들이 고객사의 Pain Point를 어떻게 해결하고 어떤 가치를 주는지 요약 (3문장 내외)

LGU+ 상품 목록:
${productList}

응답 JSON 구조:
{
  "recommendedProductIds": ["ID1", "ID2", "ID3", "ID4", "ID5"],
  "insight": "AI 인사이트 문구",
  "trend": "시장 분석 내용",
  "background": "제안 배경 내용"
}`;

      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: prompt,
        config: {
          responseMimeType: "application/json",
        }
      });

      const result = JSON.parse(response.text || '{}');
      const recommendedIds = Array.isArray(result.recommendedProductIds) 
        ? result.recommendedProductIds.filter((id: string) => PRODUCTS.some(p => p.id === id))
        : recommendedProducts.map(p => p.id);

      setProposedProducts(recommendedIds.slice(0, 5));
      if (result.insight) setAiInsight(result.insight);
      
      setProposalContent({
        trend: result.trend || "",
        background: result.background || "",
        products: recommendedIds
      });
      setLastAnalyzedName(clientName);

    } catch (error) {
      console.error("AI curation failed:", error);
      // Only set defaults if we don't have existing selections
      if (proposedProducts.length === 0) {
        setProposedProducts(recommendedProducts.map(p => p.id));
      }
    } finally {
      setIsAiLoading(false);
      setStep(2);
    }
  };

  const toggleProposed = (id: string) => {
    setProposedProducts(prev => 
      prev.includes(id) ? prev.filter(pId => pId !== id) : [...prev, id]
    );
  };

  const generateLink = () => {
    const params = new URLSearchParams();
    if (clientName) params.set('comp', clientName);
    params.set('industry', selectedIndustry);
    params.set('size', selectedSize);
    params.set('prods', proposedProducts.join(','));
    return `${window.location.origin}/view?${params.toString()}`;
  };

  const copyToClipboard = async () => {
    await navigator.clipboard.writeText(generateLink());
    setIsCopied(true);
    setTimeout(() => setIsCopied(false), 2000);
  };

  // Group products by category
  const groupedProducts = useMemo(() => {
    const groups: Record<string, Product[]> = {};
    PRODUCTS.forEach(prod => {
      if (!groups[prod.category]) {
        groups[prod.category] = [];
      }
      groups[prod.category].push(prod);
    });
    return groups;
  }, []);

  const handleNavigate = (page: 'builder' | 'share' | 'preview') => {
    if (page === 'builder') {
      if (!clientName) setStep(1);
      else setStep(2);
      setIsPreviewing(false);
    } else if (page === 'share') {
      setStep(3);
      setIsPreviewing(false);
    } else if (page === 'preview') {
      setIsPreviewing(true);
    }
  };

  const handleBuildPage = async () => {
    if (clientName && clientName !== lastAnalyzedName) {
      await handleAutoCuration();
    }
    // Update proposal content with current selection before transitioning to ensure it's saved
    setProposalContent(prev => ({
      trend: prev?.trend || "",
      background: prev?.background || "",
      products: proposedProducts
    }));
    setStep(3);
    setHasBuilt(true);
    setIsPreviewing(true); // Automatically navigate to Preview
  };

  const handleReset = () => {
    setClientName('');
    setSelectedIndustry('Manufacturing');
    setSelectedSize('Large');
    setProposedProducts([]);
    setStep(1);
    setIsPreviewing(false);
    setHasBuilt(false);
    setProposalContent(null);
    setAiInsight('업종과 규모를 선택하시면 AI가 최적의 제안 통찰을 제공합니다.');
  };

  const handleToggleExpandAll = () => {
    const categories = Object.keys(groupedProducts);
    if (expandedCategories.length === categories.length) {
      setExpandedCategories([]);
    } else {
      setExpandedCategories(categories);
    }
  };

  const handleToggleSelectAll = (checked: boolean) => {
    if (checked) {
      const allIds = PRODUCTS.map(p => p.id);
      setProposedProducts(allIds);
    } else {
      setProposedProducts([]);
    }
  };

  const toggleCategorySelection = (categoryProducts: Product[]) => {
    const categoryIds = categoryProducts.map(p => p.id);
    const allSelected = categoryIds.every(id => proposedProducts.includes(id));
    
    if (allSelected) {
      setProposedProducts(prev => prev.filter(id => !categoryIds.includes(id)));
    } else {
      setProposedProducts(prev => {
        const otherIds = prev.filter(id => !categoryIds.includes(id));
        return [...otherIds, ...categoryIds];
      });
    }
  };

  const isAllSelected = proposedProducts.length === PRODUCTS.length;
  const isAllExpanded = expandedCategories.length === Object.keys(groupedProducts).length;

  if (isPreviewing) {
    return (
      <ViewerPage 
        isPreview 
        onBack={() => setIsPreviewing(false)} 
        onNavigate={handleNavigate}
        currentStep={step}
        previewData={{
          clientName,
          industry: selectedIndustry,
          size: selectedSize,
          prodIds: proposedProducts,
          dynamicContent: proposalContent ? { ...proposalContent, products: proposedProducts } : undefined
        }}
      />
    );
  }

  return (
    <div className="flex flex-col min-h-screen bg-[#f4f4f0]">
      {/* Top Navigation Bar */}
      <header className="h-16 lg:h-20 bg-[#2d2a28] text-white flex items-center justify-between px-4 lg:px-8 sticky top-0 z-[60] shrink-0">
        <div className="flex items-center gap-4 lg:gap-8 overflow-hidden">
          <div className="flex items-center gap-2 lg:gap-3 shrink-0">
             <div className="w-8 h-8 lg:w-10 lg:h-10 bg-[#ff2e98] rounded-xl flex items-center justify-center shadow-lg shadow-[#ff2e98]/20 text-white font-black italic">
               <span className="text-sm lg:text-base">U+</span>
             </div>
             <div className="hidden sm:flex flex-col -space-y-0.5">
               <span className="font-black text-sm lg:text-lg tracking-tighter">Enterprise</span>
               <span className="text-[8px] lg:text-[10px] text-white/40 font-bold uppercase tracking-widest">Sales Assistant</span>
             </div>
          </div>

          <nav className="flex items-center gap-4 lg:gap-10 h-full overflow-x-auto no-scrollbar whitespace-nowrap">
            {[
              { id: 'builder', label: 'Proposal Builder', isActive: step <= 2 && !isPreviewing, onClick: () => handleNavigate('builder'), disabled: false },
              { id: 'preview', label: 'Preview', isActive: isPreviewing, onClick: () => handleNavigate('preview'), disabled: !hasBuilt },
              { id: 'share', label: 'Share', isActive: step === 3 && !isPreviewing, onClick: () => handleNavigate('share'), disabled: !hasBuilt },
            ].map((item) => (
              <button 
                key={item.id}
                onClick={item.onClick}
                disabled={item.disabled}
                className={cn(
                  "text-xs lg:text-sm font-bold tracking-tight transition-all relative h-full px-2 flex items-center shrink-0",
                  item.isActive ? "text-white" : "text-white/40 hover:text-white/60",
                  item.disabled && "opacity-20 cursor-not-allowed"
                )}
              >
                {item.label}
                {item.isActive && (
                  <motion.div layoutId="nav-active" className="absolute bottom-0 left-0 right-0 h-1 bg-[#ff2e98] rounded-t-full shadow-[0_-4px_12px_rgba(255,46,152,0.4)]" />
                )}
              </button>
            ))}
          </nav>
        </div>

        <div className="flex items-center gap-2 lg:gap-3 shrink-0">
          <button
            onClick={() => downloadPrdHtml()}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-white text-xs font-bold transition-all border border-white/10 shadow-sm"
            title="PRD 명세서를 HTML 파일로 다운로드합니다"
          >
            <FileText className="w-3.5 h-3.5 text-[#ff2e98]" />
            <span className="hidden sm:inline">PRD HTML 다운로드</span>
            <span className="sm:hidden">PRD</span>
          </button>
        </div>
      </header>

      <div className="flex flex-1 flex-col lg:flex-row overflow-hidden relative">
        <button 
          onClick={() => setIsSidebarOpen(!isSidebarOpen)}
          className={cn(
            "hidden lg:flex absolute top-6 z-50 p-2 bg-white rounded-lg border border-black/10 shadow-sm hover:bg-black/5 transition-all duration-300 items-center justify-center",
            isSidebarOpen ? "left-[19.25rem]" : "left-6"
          )}
          title={isSidebarOpen ? "입력창 닫기" : "입력창 열기"}
        >
          {isSidebarOpen ? <PanelLeftClose className="w-5 h-5" /> : <PanelLeftOpen className="w-5 h-5" />}
        </button>

        {/* Mobile Toggle Button */}
        <button 
          onClick={() => setIsSidebarOpen(!isSidebarOpen)}
          className="lg:hidden fixed bottom-6 right-6 z-50 w-12 h-12 bg-[#ff2e98] text-white rounded-full shadow-2xl flex items-center justify-center"
        >
          {isSidebarOpen ? <PanelLeftClose className="w-6 h-6" /> : <PanelLeftOpen className="w-6 h-6" />}
        </button>

        {/* Persistent Side Input Panel */}
        <aside className={cn(
          "bg-white border-b lg:border-b-0 lg:border-r border-black/5 flex flex-col transition-all duration-300",
          isSidebarOpen ? "h-auto lg:w-80" : "h-0 lg:w-0 overflow-hidden"
        )}>
          <div className="flex-1 p-6 pt-10 lg:px-8 lg:pt-[88px] lg:pb-8 flex flex-col gap-8 lg:gap-10 overflow-y-auto max-h-[50vh] lg:max-h-full">
            <div className="space-y-2">
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-[#ff2e98] animate-pulse" />
                <p className="text-xs font-black text-[#ff2e98] uppercase tracking-[0.2em] font-mono">Step 1. Segment Targeting</p>
              </div>
            </div>

          <div className="space-y-6">
            <div className="space-y-3">
              <label className="text-xs font-bold text-[#3d3937]">고객사명</label>
              <input 
                type="text" 
                placeholder="예) 한국전력, AWS"
                value={clientName}
                onChange={(e) => setClientName(e.target.value)}
                disabled={step > 1 && !isPreviewing}
                className="w-full bg-[#f4f4ee] border-transparent rounded-xl px-5 py-4 text-sm font-bold focus:bg-white focus:ring-2 focus:ring-[#ff2e98] transition-all"
              />
            </div>

            <div className="space-y-3">
              <label className="text-xs font-bold text-[#3d3937]">업종 (Industry)</label>
              <div className="relative">
                <select 
                   value={selectedIndustry}
                   onChange={(e) => setSelectedIndustry(e.target.value as Industry)}
                   disabled={step > 1 && !isPreviewing}
                   className="w-full bg-[#f4f4ee] border-transparent rounded-xl px-5 py-4 text-sm font-bold appearance-none cursor-pointer focus:bg-white focus:ring-2 focus:ring-[#ff2e98] transition-all"
                >
                  {INDUSTRIES.map(ind => <option key={ind} value={ind}>{ind}</option>)}
                </select>
                <ChevronDown className="absolute right-4 top-1/2 -translate-y-1/2 w-4 h-4 text-[#82817e] pointer-events-none" />
              </div>
            </div>

            <div className="space-y-3">
              <label className="text-xs font-bold text-[#3d3937]">규모 (Size)</label>
              <div className="flex p-1 bg-[#f4f4ee] rounded-xl">
                 {SIZES.map((s) => (
                   <button
                     key={s.value}
                     onClick={() => setSelectedSize(s.value)}
                     disabled={step > 1 && !isPreviewing}
                     className={cn(
                       "flex-1 py-3 text-xs font-black rounded-lg transition-all",
                       selectedSize === s.value 
                         ? "bg-white text-[#ff2e98] shadow-sm border border-[#ff2e98]" 
                         : "text-[#82817e] hover:bg-black/5"
                     )}
                   >
                     {s.label.split(' ')[0]}
                   </button>
                 ))}
              </div>
            </div>
          </div>

          <div className="mt-8">
            {step === 1 ? (
              <button
                disabled={!clientName || isAiLoading}
                onClick={handleAutoCuration}
                className="w-full bg-[#3d3937] text-white py-4 rounded-2xl font-bold hover:bg-[#ff2e98] disabled:opacity-30 transition-all flex items-center justify-center gap-2"
              >
                {isAiLoading ? (
                   <div className="flex items-center gap-2">
                     <div className="w-4 h-4 border-2 border-white/20 border-t-white rounded-full animate-spin" />
                     <span>AI 분석 중...</span>
                   </div>
                ) : "다음 단계로 (AI 분석 추천)"}
              </button>
            ) : (
              <button onClick={() => setStep(1)} className="w-full border border-black/10 py-4 rounded-2xl font-bold text-[#82817e] hover:bg-black/5 transition-all">타겟 수정</button>
            )}
          </div>
        </div>

        {/* Sales AI Insight Card */}
        <div className="p-6 lg:p-8 pt-0 mt-auto">
            <div className="bg-[#2d2a28] rounded-xl p-6 text-white relative flex flex-col gap-3 shadow-2xl border border-white/5">
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 rounded-full bg-[#ff2e98] animate-pulse" />
                <h4 className="font-bold italic text-sm">Sales AI Insight</h4>
              </div>
              <p className="text-[11px] leading-relaxed text-white/70 font-medium">
                {aiInsight}
              </p>
            </div>
          </div>
        </aside>

        {/* Curation Area */}
        <main className="flex-1 p-6 lg:p-12 overflow-y-auto">
          <div className="max-w-7xl mx-auto space-y-8 lg:space-y-12">
            <AnimatePresence mode="wait">
              {introProductId ? (
                <motion.div
                  key="intro-view"
                  initial={{ opacity: 0, scale: 0.98 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.98 }}
                  className="space-y-12 pb-20"
                >
                  {(() => {
                    const prod = PRODUCTS.find(p => p.id === introProductId);
                    if (!prod) return null;
                    const Icon = CategoryIconMap[prod.category] || Network;
                    
                    const detailedInfo: Record<string, { catchphrase: string, features: string[] }> = {
                      'I001': {
                        catchphrase: '국내 1위 고품질 전용 회선 인터넷',
                        features: ['국내 최다 고정 IP 제공', '24시간 관제 센터 실시간 대응', 'SLA 보장으로 다운타임 제로화', '기업 전용 백본망 직접 연결']
                      },
                      'I002': {
                        catchphrase: '합리적인 가격의 오피스 통합 인터넷',
                        features: ['CCTV/전화 결합 시 최대 할인', '간편한 설치 및 개통 프로세스', 'SME 맞춤형 요금 체계', '안정적인 오피스 무선 환경 지원']
                      },
                      'I003': {
                        catchphrase: '무선으로 즐기는 초고속 비즈니스 인터넷',
                        features: ['공사 없는 즉시 개통', 'LTE/5G 전국망 커버리지', '휴대용 라우터로 외부 작업 최적화', '유연한 데이터 전용 요금제']
                      },
                      'I004': {
                        catchphrase: '안전하고 깨끗한 교육 전용 네트워크',
                        features: ['스마트 보급 사업 최적화 서비스', '실시간 유해 콘텐츠 필터링', '대규모 다수 기기 접속 안정성', '교육청 보안 지침 완벽 준수']
                      },
                      'I006': {
                        catchphrase: '사무실 전역 끊김 없는 프리미엄 와이파이',
                        features: ['물리적인 사각지대 제로 구축', '사내/손님용 네트워크 완벽 분리', '접속 기기별 대역폭 자동 조절', '중앙 관리형 클라우드 AP']
                      }
                    };

                    const info = detailedInfo[prod.id] || {
                      catchphrase: 'LGU+가 제안하는 비즈니스 혁신 솔루션',
                      features: ['업계 최고 수준의 가동률 보장', '전문 AM의 1:1 맞춤 컨설팅', '실시간 모니터링 시스템 제공', '강력한 보안 프로토콜 적용']
                    };

                    return (
                      <>
                        <header className="flex items-center justify-between">
                          <div className="space-y-2">
                             <p className="text-xs font-black text-[#ff2e98] uppercase tracking-[0.2em] font-mono">Product Deep Dive</p>
                             <h2 className="text-4xl font-black tracking-tighter text-[#3d3937]">
                               {prod.name} <span className="text-[#ff2e98]">상세 안내</span>
                             </h2>
                          </div>
                          <button 
                            onClick={() => setIntroProductId(null)}
                            className="flex items-center gap-2 px-6 py-3 rounded-xl border border-black/10 font-bold hover:bg-black/5 transition-all text-sm"
                          >
                            <ChevronLeft className="w-4 h-4" />
                            목록으로 돌아가기
                          </button>
                        </header>

                        <motion.div 
                          initial={{ opacity: 0, y: 20 }}
                          animate={{ opacity: 1, y: 0 }}
                          className="bg-white rounded-2xl p-8 lg:p-12 shadow-sm border border-black/5 grid lg:grid-cols-2 gap-12 items-center"
                        >
                          <div className="space-y-8">
                            <div className="space-y-4">
                              <div className="flex items-center gap-3">
                                <div className="w-12 h-12 bg-[#ff2e98]/10 rounded-2xl flex items-center justify-center">
                                  <Icon className="w-6 h-6 text-[#ff2e98]" />
                                </div>
                                <span className="text-sm font-black text-[#ff2e98] uppercase tracking-widest">{prod.category}</span>
                              </div>
                              <h3 className="text-3xl lg:text-4xl font-black tracking-tighter text-[#3d3937] leading-[1.1]">{info.catchphrase}</h3>
                              <p className="text-lg font-medium text-[#82817e] leading-relaxed">
                                {prod.description}
                              </p>
                            </div>

                            <div className="space-y-4">
                               <div className="flex items-center gap-2">
                                 <div className="w-1.5 h-1.5 rounded-full bg-[#ff2e98]" />
                                 <span className="text-xs font-black uppercase tracking-widest text-[#3d3937]">Key Features</span>
                               </div>
                               <ul className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                                 {info.features.map((feature, i) => (
                                   <li key={i} className="flex items-center gap-2 text-sm text-[#82817e] font-medium border-b border-black/[0.03] pb-2">
                                     <Plus className="w-3 h-3 text-[#ff2e98]" />
                                     {feature}
                                   </li>
                                 ))}
                               </ul>
                            </div>

                            <div className="pt-4">
                               <button 
                                 onClick={() => {
                                   if (!proposedProducts.includes(prod.id)) {
                                     toggleProposed(prod.id);
                                   }
                                   setIntroProductId(null);
                                 }}
                                 className="bg-[#3d3937] text-white px-8 py-4 rounded-xl font-black hover:bg-[#ff2e98] transition-all flex items-center gap-2 shadow-xl shadow-black/20"
                               >
                                 이 상품 제안에 추가하기
                                 <ArrowRight className="w-4 h-4" />
                               </button>
                            </div>
                          </div>
                          <div className="aspect-square bg-[#f4f4ee] rounded-xl flex items-center justify-center relative overflow-hidden">
                             <div className="absolute inset-0 bg-[#ff2e98] opacity-[0.03] blur-3xl rounded-full" />
                             <Icon className="w-32 h-32 text-[#ff2e98]/20" />
                             <div className="absolute bottom-6 left-6 right-6 bg-white/80 backdrop-blur-md p-6 rounded-xl border border-white/40 shadow-xl">
                                <p className="text-[10px] font-bold text-[#82817e] mb-1 uppercase tracking-widest">Optimized Context</p>
                                <p className="text-sm font-black text-[#3d3937]">{selectedIndustry} 산업군 {selectedSize} 대상 최적 솔루션</p>
                             </div>
                          </div>
                        </motion.div>
                      </>
                    );
                  })()}
                </motion.div>
              ) : step <= 2 ? (
                <motion.div
                  key="builder-main"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  className="space-y-8 lg:space-y-12 pb-24"
                >
                  {/* Step Header */}
                  <header className="flex flex-col md:flex-row md:items-center justify-between gap-6 bg-white/50 backdrop-blur-md p-6 lg:p-10 rounded-2xl border border-black/5 shadow-sm">
                    <div className="space-y-2">
                      <div className="flex items-center gap-2">
                        <span className="w-2 h-2 rounded-full bg-[#ff2e98] animate-pulse" />
                        <p className="text-xs font-black text-[#ff2e98] uppercase tracking-[0.2em] font-mono">Step 2. Product Curation</p>
                      </div>
                      <h2 className="text-3xl lg:text-4xl font-black tracking-tighter text-[#3d3937]">
                        {clientName || '고객사'} <span className="text-[#ff2e98]">제안 서비스 구성</span>
                      </h2>
                    </div>
                    <div className="flex items-center gap-4">
                       <div className="hidden lg:flex flex-col items-end px-6 border-r border-black/10">
                         <span className="text-xs font-bold text-[#82817e] uppercase tracking-widest">Selected Items</span>
                         <span className="text-xl font-black text-[#3d3937]">{proposedProducts.length}개</span>
                       </div>
                       <div className="flex items-center gap-3">
                         <button 
                           onClick={handleReset}
                           className="px-6 py-4 rounded-xl border border-black/10 font-bold text-[#82817e] hover:bg-black/5 transition-all text-sm whitespace-nowrap"
                         >
                           초기화
                         </button>
                         <button 
                           onClick={handleBuildPage}
                           disabled={isAiLoading || proposedProducts.length === 0}
                           className="flex-1 md:flex-initial bg-[#ff2e98] text-white px-8 lg:px-12 py-4 lg:py-5 rounded-xl font-black hover:bg-[#ff2e98]/90 disabled:opacity-50 transition-all shadow-2xl shadow-[#ff2e98]/30 flex items-center justify-center gap-3 text-base lg:text-lg group"
                         >
                           {isAiLoading ? (
                             <div className="flex items-center gap-3">
                               <div className="w-5 h-5 border-3 border-white/20 border-t-white rounded-full animate-spin" />
                               <span>소개서 빌드중...</span>
                             </div>
                           ) : (
                             <>
                               <span>서비스 소개서 빌드</span>
                               <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
                             </>
                           )}
                         </button>
                       </div>
                    </div>
                  </header>

                  <div className="grid lg:grid-cols-12 gap-8 items-start">
                    {/* Left: Product Library */}
                    <div className="lg:col-span-7 space-y-8">
                       <div className="flex items-center justify-between px-2 py-6 border-b border-black/5 h-[88px]">
                          <div className="flex items-center gap-3">
                             <div className="w-1.5 h-6 bg-[#ff2e98] rounded-full" />
                             <h3 className="text-xl font-black text-[#3d3937]">솔루션 라이브러리</h3>
                          </div>

                          <div className="flex items-center gap-6 bg-[#f8f8f5] px-5 py-2.5 rounded-xl border border-black/[0.03]">
                             <label className="flex items-center gap-2.5 cursor-pointer group">
                                <div className="relative flex items-center justify-center">
                                   <input 
                                      type="checkbox" 
                                      className="peer sr-only"
                                      checked={isAllSelected}
                                      onChange={(e) => handleToggleSelectAll(e.target.checked)}
                                   />
                                   <div className="w-5 h-5 rounded-lg border-2 border-black/10 peer-checked:bg-[#ff2e98] peer-checked:border-[#ff2e98] transition-all" />
                                   <Check className="absolute w-3.5 h-3.5 text-white opacity-0 peer-checked:opacity-100 transition-opacity" />
                                </div>
                                <span className="text-xs font-bold text-[#3d3937]">전체 선택</span>
                             </label>

                             <div className="w-px h-4 bg-black/10" />

                             <button 
                                onClick={handleToggleExpandAll}
                                className="text-xs font-bold text-[#82817e] hover:text-[#ff2e98] transition-colors flex items-center gap-2"
                             >
                                {isAllExpanded ? (
                                   <>
                                      <Minus className="w-3.5 h-3.5" />
                                      전체 접기
                                   </>
                                ) : (
                                   <>
                                      <Plus className="w-3.5 h-3.5" />
                                      전체 펼치기
                                   </>
                                )}
                             </button>
                          </div>

                          <span className="text-xs font-black text-[#82817e] uppercase tracking-widest">TOTAL {PRODUCTS.length} PRODUCTS</span>
                       </div>

                       <div className="space-y-4">
                          {(Object.entries(groupedProducts) as [string, Product[]][]).map(([category, products]) => {
                            const isExpanded = expandedCategories.includes(category);
                            
                            return (
                              <div key={category} className="space-y-4">
                                <button 
                                  onClick={() => {
                                    setExpandedCategories(prev => 
                                      prev.includes(category) 
                                        ? prev.filter(c => c !== category) 
                                        : [...prev, category]
                                    );
                                  }}
                                  className={cn(
                                    "w-full flex items-center justify-between p-6 rounded-2xl border transition-all duration-300",
                                    isExpanded 
                                      ? "bg-white text-[#ff2e98] border-[#ff2e98]/20 shadow-xl shadow-[#ff2e98]/5" 
                                      : "bg-[#f4f4ee] text-[#3d3937] border-transparent hover:bg-black/5"
                                  )}
                                >
                                  <div className="flex items-center gap-4">
                                     <div className={cn(
                                       "w-1.5 h-6 rounded-full transition-colors",
                                       isExpanded ? "bg-[#ff2e98]" : "bg-[#82817e]/30"
                                     )} />
                                     <div className="flex items-center gap-3">
                                        {isExpanded ? <ChevronDown className="w-5 h-5" /> : <ChevronRight className="w-5 h-5" />}
                                        
                                        {/* Category Select All Checkbox */}
                                        <div 
                                          onClick={(e) => {
                                            e.stopPropagation();
                                            toggleCategorySelection(products);
                                          }}
                                          className="relative flex items-center justify-center p-1 group/cb"
                                        >
                                          <div className={cn(
                                            "w-4 h-4 rounded border transition-all flex items-center justify-center",
                                            products.every(p => proposedProducts.includes(p.id))
                                              ? "bg-[#ff2e98] border-[#ff2e98]" 
                                              : "border-black/20 group-hover/cb:border-[#ff2e98]/50 bg-white"
                                          )}>
                                            {products.every(p => proposedProducts.includes(p.id)) && <Check className="w-3 h-3 text-white" />}
                                            {!products.every(p => proposedProducts.includes(p.id)) && products.some(p => proposedProducts.includes(p.id)) && (
                                              <div className="w-2 h-0.5 bg-[#ff2e98]" />
                                            )}
                                          </div>
                                        </div>

                                        <span className="font-black text-xl tracking-tighter">{category}</span>
                                     </div>
                                  </div>
                                  <span className={cn(
                                    "text-xs font-black uppercase tracking-widest px-3 py-1.5 rounded-full",
                                    isExpanded ? "bg-[#ff2e98]/10 text-[#ff2e98]" : "bg-black/5 text-[#82817e]"
                                  )}>
                                    {products.length} Products
                                  </span>
                                </button>

                                <AnimatePresence>
                                  {isExpanded && (
                                    <motion.div 
                                      initial={{ opacity: 0, y: -10 }}
                                      animate={{ opacity: 1, y: 0 }}
                                      exit={{ opacity: 0, y: -10 }}
                                      className="grid grid-cols-1 md:grid-cols-2 gap-4 pb-4"
                                    >
                                      {products.map(prod => {
                                        const Icon = CategoryIconMap[prod.category] || Network;
                                       const isProposed = proposedProducts.includes(prod.id);
                                       
                                       return (
                                         <motion.div
                                           key={prod.id}
                                           layout
                                           whileHover={{ scale: 1.02 }}
                                           className={cn(
                                             "group relative bg-white rounded-2xl p-5 shadow-sm border-2 transition-all duration-300",
                                             isProposed 
                                              ? "border-[#3d3937] shadow-xl shadow-black/10 ring-4 ring-black/5" 
                                              : "border-black/5 hover:border-black/30 bg-white"
                                           )}
                                         >
                                            <div className="flex items-start gap-4">
                                               <div className={cn(
                                                 "w-16 h-16 rounded-xl flex items-center justify-center shrink-0 transition-colors",
                                                 isProposed ? "bg-[#3d3937] text-white" : "bg-[#f4f4ee] text-[#82817e] group-hover:bg-black/10 group-hover:text-black"
                                               )}>
                                                   <Icon className="w-8 h-8" />
                                                </div>
                                                <div className="flex-1 min-w-0 pr-8">
                                                   <p className={cn(
                                                     "text-[11px] font-black uppercase tracking-widest mb-1",
                                                     isProposed ? "text-[#3d3937]" : "text-[#82817e]"
                                                   )}>{prod.category}</p>
                                                   <h4 className="text-sm font-black text-[#3d3937] truncate mb-1">{prod.name}</h4>
                                                   <p className="text-xs font-medium text-[#82817e] line-clamp-2 leading-snug">{prod.description}</p>
                                                </div>
                                             </div>

                                             <div className="mt-4 flex gap-2">
                                                <button 
                                                  onClick={() => toggleProposed(prod.id)}
                                                  className={cn(
                                                    "flex-1 py-2.5 rounded-lg text-xs font-black tracking-widest transition-all",
                                                    isProposed 
                                                      ? "bg-[#3d3937] text-white shadow-lg shadow-black/20" 
                                                      : "bg-white border border-black/10 text-[#82817e] hover:bg-black/10 hover:text-black"
                                                  )}
                                                >
                                                   {isProposed ? "제안 취소" : "+ 제안 추가"}
                                                </button>

                                                <button 
                                                  title="상품소개"
                                                  onClick={(e) => { e.stopPropagation(); setIntroProductId(prod.id); }}
                                                  className="w-10 h-10 rounded-lg bg-white border border-black/10 flex items-center justify-center text-[#82817e] hover:bg-black hover:text-white transition-all focus:outline-none"
                                                >
                                                   <ExternalLink className="w-4 h-4" />
                                                </button>
                                             </div>

                                             {isProposed && (
                                               <div className="absolute top-4 right-4 w-2 h-2 rounded-full bg-[#3d3937] shadow-[0_0_10px_rgba(0,0,0,0.8)]" />
                                             )}
                                          </motion.div>
                                        );
                                      })}
                                    </motion.div>
                                  )}
                                </AnimatePresence>
                              </div>
                            );
                          })}
                       </div>
                    </div>

                    {/* Right: Composition Summary */}
                    <div className="lg:col-span-5 space-y-8 sticky top-32">
                       <div className="flex items-center gap-3 px-2 py-6 border-b border-black/5 h-[88px]">
                          <div className="w-1.5 h-6 bg-[#3d3937] rounded-full" />
                          <h3 className="text-xl font-black text-[#3d3937]">고객 커스텀 솔루션</h3>
                       </div>

                       <div className="bg-[#f4f4ee]/80 backdrop-blur-md rounded-2xl p-8 border border-black/5 flex flex-col gap-8 shadow-inner min-h-[500px]">
                          {/* Proposed Section */}
                          <div className="space-y-4">
                             <div className="flex items-center justify-between px-1">
                               <div className="flex items-center gap-3">
                                 <div className="w-2 h-2 rounded-full bg-[#ff2e98]" />
                                 <h4 className="text-xs font-black uppercase tracking-[0.2em] text-[#ff2e98]">New Proposed</h4>
                               </div>
                               <span className="text-xs font-bold text-[#82817e]">{proposedProducts.length} Items</span>
                             </div>
                             
                             <div className="space-y-3">
                                <AnimatePresence mode="popLayout">
                                  {proposedProducts.length === 0 ? (
                                    <div className="h-24 border-2 border-dashed border-[#ff2e98]/10 rounded-2xl flex flex-col items-center justify-center gap-2 bg-[#ff2e98]/[0.02]">
                                       <span className="text-[10px] font-bold text-[#ff2e98]/40">제안 상품 없음</span>
                                    </div>
                                  ) : (
                                    proposedProducts.map(id => {
                                      const prod = PRODUCTS.find(p => p.id === id);
                                      if (!prod) return null;
                                      const Icon = CategoryIconMap[prod.category] || Network;
                                      return (
                                        <motion.div
                                          key={`cur-prop-${id}`}
                                          layout
                                          initial={{ opacity: 0, x: 20 }}
                                          animate={{ opacity: 1, x: 0 }}
                                          exit={{ opacity: 0, scale: 0.95 }}
                                          className="bg-white p-4 rounded-2xl shadow-sm border border-black/5 flex items-center gap-4 group"
                                        >
                                          <div className="w-12 h-12 bg-[#ff2e98] text-white rounded-xl flex items-center justify-center shrink-0 shadow-lg shadow-[#ff2e98]/20">
                                             <Icon className="w-6 h-6" />
                                          </div>
                                          <div className="flex-1 min-w-0">
                                             <h5 className="text-sm font-black text-[#3d3937] truncate">{prod.name}</h5>
                                             <p className="text-[10px] font-medium text-[#82817e] uppercase tracking-wider">{prod.category}</p>
                                          </div>
                                          <button 
                                            onClick={() => toggleProposed(id)}
                                            className="w-8 h-8 rounded-full bg-red-50 text-red-500 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center"
                                          >
                                             <Minus className="w-4 h-4" />
                                          </button>
                                        </motion.div>
                                      );
                                    })
                                  )}
                                </AnimatePresence>
                             </div>
                          </div>
                       </div>
                    </div>
                  </div>
                </motion.div>
              ) : step === 3 ? (
                <motion.div
                  key="step3"
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="max-w-3xl mx-auto space-y-12 py-12"
                >
                  <div className="flex justify-start">
                    <button 
                      onClick={() => setIsPreviewing(true)}
                      className="flex items-center gap-2 px-4 py-2 rounded-xl bg-[#f4f4ee] hover:bg-black/5 transition-all text-[#82817e] font-bold text-sm border border-black/5 group"
                    >
                      <ChevronLeft className="w-4 h-4 group-hover:-translate-x-1 transition-transform" />
                      Back
                    </button>
                  </div>

                  <div className="text-center space-y-4">
                    <div className="w-20 h-20 bg-[#ff2e98] rounded-xl mx-auto flex items-center justify-center shadow-2xl shadow-[#ff2e98]/40 animate-bounce">
                      <Send className="w-10 h-10 text-white" />
                    </div>
                    <h2 className="text-4xl font-bold tracking-tighter text-[#3d3937]">서비스 소개서 생성 완료!</h2>
                    <p className="text-lg text-[#82817e]">
                      {clientName ? `${clientName} 고객님을 위한` : "고객님을 위한"} 전용 링크가 생성되었습니다. <br />
                      아래 링크를 복사하여 메신저나 이메일로 전달해 보세요.
                    </p>
                  </div>

                  <div className="bg-white p-10 rounded-2xl border border-[#ff2e98]/20 shadow-xl space-y-8 relative overflow-hidden">
                    <div className="absolute top-0 right-0 p-3">
                      <div className="w-2 h-2 rounded-full bg-[#ff2e98] animate-ping" />
                    </div>

                    <div className="space-y-4">
                      <div className="flex items-center justify-between text-xs font-bold text-[#82817e] uppercase tracking-widest px-1">
                        <span>Custom Page URL</span>
                        <span className="text-[#ff2e98]">Active</span>
                      </div>
                      <div className="flex gap-2">
                         <div className="flex-1 bg-[#f4f4ee] p-4 rounded-2xl text-xs font-mono break-all border border-black/5 text-[#3d3937]">
                           {generateLink()}
                         </div>
                         <button 
                          onClick={copyToClipboard}
                          className={cn(
                            "px-6 rounded-2xl font-bold flex items-center justify-center gap-2 transition-all whitespace-nowrap",
                            isCopied ? "bg-green-500 text-white" : "bg-[#ff2e98] text-white hover:bg-[#ff2e98]/90"
                          )}
                         >
                           {isCopied ? <><Copy className="w-4 h-4" /> COPIED</> : <><Copy className="w-4 h-4" /> COPY LINK</>}
                         </button>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
                       <button 
                         onClick={() => setIsPreviewing(true)}
                         className="flex items-center justify-center gap-2 py-3.5 rounded-xl border border-black/10 font-bold hover:bg-black/5 transition-all text-[#ff2e98] bg-white shadow-sm text-sm"
                       >
                          <ExternalLink className="w-4 h-4" />
                          미리보기 (Preview)
                       </button>
                       <button 
                         onClick={() => setIsEmailModalOpen(true)}
                         className="flex items-center justify-center gap-2 py-3.5 rounded-xl border border-black/10 font-bold hover:bg-black/5 transition-all text-[#82817e] bg-white shadow-sm text-sm"
                       >
                          <Mail className="w-4 h-4" />
                          메일보내기
                       </button>
                       <button 
                         onClick={() => downloadProposalHtml({
                           clientName,
                           industry: selectedIndustry,
                           size: selectedSize,
                           prodIds: proposedProducts,
                           dynamicContent: proposalContent
                         })}
                         className="flex items-center justify-center gap-2 py-3.5 rounded-xl border border-[#ff2e98]/30 font-bold hover:bg-[#ff2e98]/10 transition-all text-[#ff2e98] bg-[#fff5f9] shadow-sm text-sm"
                         title="제안서를 독립 실행 가능한 HTML 파일로 다운로드합니다"
                       >
                          <FileDown className="w-4 h-4" />
                          제안서 HTML 다운로드
                       </button>
                       <button 
                         onClick={() => downloadPrdHtml()}
                         className="flex items-center justify-center gap-2 py-3.5 rounded-xl border border-black/10 font-bold hover:bg-black/5 transition-all text-[#3d3937] bg-white shadow-sm text-sm"
                         title="최신 PRD 문서를 HTML 파일로 다운로드합니다"
                       >
                          <FileText className="w-4 h-4 text-[#ff2e98]" />
                          PRD HTML 다운로드
                       </button>
                    </div>
                  </div>

                  {/* Email Modal */}
                  <AnimatePresence>
                    {isEmailModalOpen && (
                      <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 lg:p-0">
                        <motion.div 
                          initial={{ opacity: 0 }}
                          animate={{ opacity: 1 }}
                          exit={{ opacity: 0 }}
                          onClick={() => setIsEmailModalOpen(false)}
                          className="absolute inset-0 bg-black/60 backdrop-blur-sm"
                        />
                        <motion.div 
                          initial={{ opacity: 0, scale: 0.95, y: 20 }}
                          animate={{ opacity: 1, scale: 1, y: 0 }}
                          exit={{ opacity: 0, scale: 0.95, y: 20 }}
                          className="bg-white w-full max-w-xl rounded-2xl shadow-2xl relative z-10 overflow-hidden"
                        >
                          <div className="p-8 lg:p-10 space-y-8">
                            <div className="flex items-center justify-between">
                              <div className="flex items-center gap-3">
                                <div className="w-12 h-12 bg-[#ff2e98]/10 rounded-2xl flex items-center justify-center">
                                  <Mail className="w-6 h-6 text-[#ff2e98]" />
                                </div>
                                <div>
                                  <h3 className="text-xl font-black text-[#3d3937] tracking-tight">서비스 소개서 메일 발송</h3>
                                  <p className="text-xs font-bold text-[#82817e] uppercase tracking-widest mt-0.5">Send Proposal via Email</p>
                                </div>
                              </div>
                              <button 
                                onClick={() => setIsEmailModalOpen(false)}
                                className="w-10 h-10 rounded-full bg-black/5 flex items-center justify-center hover:bg-black/10 transition-colors"
                              >
                                <Minus className="w-5 h-5 text-[#82817e]" />
                              </button>
                            </div>

                            <form className="space-y-6" onSubmit={(e) => {
                              e.preventDefault();
                              const formData = new FormData(e.currentTarget);
                              const email = formData.get('email');
                              const subject = formData.get('subject');
                              const body = formData.get('body');
                              
                              window.location.href = `mailto:${email}?subject=${encodeURIComponent(subject as string)}&body=${encodeURIComponent(body as string)}`;
                              setIsEmailModalOpen(false);
                            }}>
                              <div className="space-y-4">
                                <div className="space-y-2">
                                  <label className="text-xs font-black text-[#3d3937] uppercase tracking-widest ml-1">받는 사람 (Recipient)</label>
                                  <input 
                                    name="email"
                                    type="email" 
                                    required
                                    placeholder="example@company.com"
                                    className="w-full bg-[#f4f4ee] border-transparent rounded-lg px-6 py-4 text-sm font-bold focus:bg-white focus:ring-2 focus:ring-[#ff2e98] transition-all"
                                  />
                                </div>
                                <div className="space-y-2">
                                  <label className="text-xs font-black text-[#3d3937] uppercase tracking-widest ml-1">제목 (Subject)</label>
                                  <input 
                                    name="subject"
                                    type="text" 
                                    required
                                    defaultValue={`[LGU+ Enterprise] ${clientName || '고객사'}님께 드리는 서비스 제안서입니다.`}
                                    className="w-full bg-[#f4f4ee] border-transparent rounded-lg px-6 py-4 text-sm font-bold focus:bg-white focus:ring-2 focus:ring-[#ff2e98] transition-all"
                                  />
                                </div>
                                <div className="space-y-2">
                                  <label className="text-xs font-black text-[#3d3937] uppercase tracking-widest ml-1">내용 (Message)</label>
                                  <textarea 
                                    name="body"
                                    required
                                    rows={6}
                                    defaultValue={`안녕하세요, ${clientName || '고객님'}.

LGU+ Enterprise에서 제안드리는 비즈니스 솔루션 소개서입니다.
아래 링크를 통해 상세 내용을 확인하실 수 있습니다.

서비스 소개서 링크:
${generateLink()}

감사합니다.
LGU+ Enterprise 드림`}
                                    className="w-full bg-[#f4f4ee] border-transparent rounded-lg px-6 py-4 text-sm font-medium focus:bg-white focus:ring-2 focus:ring-[#ff2e98] transition-all resize-none"
                                  />
                                </div>
                              </div>

                              <button 
                                type="submit"
                                className="w-full bg-[#ff2e98] text-white py-5 rounded-xl font-black hover:bg-[#ff2e98]/90 transition-all shadow-xl shadow-[#ff2e98]/20 flex items-center justify-center gap-3 text-lg group"
                              >
                                <span>메일 클라이언트 열기</span>
                                <Send className="w-5 h-5 group-hover:translate-x-1 group-hover:-translate-y-1 transition-transform" />
                              </button>
                            </form>
                          </div>
                        </motion.div>
                      </div>
                    )}
                  </AnimatePresence>

                  {/* Removing stats section per user request */}
                </motion.div>
              ) : null}
            </AnimatePresence>
          </div>
        </main>
      </div>
    </div>
  );
}
