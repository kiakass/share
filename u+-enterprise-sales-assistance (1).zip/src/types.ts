export type Industry = 'Retail' | 'Platform/IT' | 'Education' | 'Manufacturing' | 'Public' | 'Medical' | 'Finance';
export type CompanySize = 'Large' | 'Medium' | 'Small';

export interface Product {
  id: string;
  name: string;
  description: string;
  longDescription?: string;
  industries: Industry[];
  sizes: CompanySize[];
  videoUrl?: string;
  brochureUrl?: string;
  category: string;
  iconName: string;
}

export interface ProposalState {
  clientName: string;
  industry: Industry;
  size: CompanySize;
  usedProducts: string[]; // IDs for "사용중 서비스"
  proposedProducts: string[]; // IDs for "추천/제안 상품"
}
